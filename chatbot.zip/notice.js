// =========================================================
// notice.js: reads notice PDFs on the device (no server).
// Rebuilds lines/tables from text positions, finds dates, amounts and required actions.
// Everything it reports is copied from the document, never invented.
// =========================================================

const NOTICE_MONTHS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
const MONTH_RE = "jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?";
const MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

// ---- 1. text positions -> rows of cells -------------------------------------------------------
// items: pdf.js textContent.items. Returns rows (top to bottom), each an array of cell strings.
function buildRows(items) {
  const toks = [];
  for (const it of items || []) {
    const s = String(it.str || "").replace(/\s+/g, " ");
    if (!s.trim() || !it.transform) continue;
    toks.push({
      s,
      x: it.transform[4],
      y: it.transform[5],
      w: it.width || s.length * 4,
      h: Math.abs(it.height) || Math.abs(it.transform[3]) || 10
    });
  }
  toks.sort((a, b) => b.y - a.y || a.x - b.x);

  const lines = [];
  for (const t of toks) {
    const line = lines[lines.length - 1];
    if (line && Math.abs(line.y - t.y) <= Math.max(2, t.h * 0.45)) line.t.push(t);
    else lines.push({ y: t.y, t: [t] });
  }

  return lines
    .map((ln) => {
      ln.t.sort((a, b) => a.x - b.x);
      const cells = [];
      const xs = [];
      const push = (c) => {
        const text = c.s.trim();
        if (text) {
          cells.push(text);
          xs.push(c.x0);
        }
      };
      let cur = null;
      for (const t of ln.t) {
        if (!cur) {
          cur = { s: t.s, x0: t.x, end: t.x + t.w, h: t.h };
          continue;
        }
        const gap = t.x - cur.end;
        if (gap > Math.max(6, cur.h * 1.4)) {
          push(cur);
          cur = { s: t.s, x0: t.x, end: t.x + t.w, h: t.h };
        } else {
          const needSpace = gap > cur.h * 0.15 && !/\s$/.test(cur.s) && !/^\s/.test(t.s);
          cur.s += (needSpace ? " " : "") + t.s;
          cur.end = t.x + t.w;
          cur.h = Math.max(cur.h, t.h);
        }
      }
      if (cur) push(cur);
      cells.xs = xs; // where each cell starts, used to re-attach wrapped lines
      cells.y = ln.y;
      cells.h = Math.max(...ln.t.map((t) => t.h));
      return cells;
    })
    .filter((r) => r.length);
}

// A cell that wrapped onto a second line ("10:00 AM to" / "01:00 PM") is re-attached to its row
function mergeWrappedCells(rows) {
  const out = [];
  for (const r of rows) {
    const prev = out[out.length - 1];
    if (prev && r.length === 1 && prev.length >= 3 && r.xs && prev.xs && prev.y > r.y && prev.y - r.y <= 1.6 * (r.h || 10)) {
      const k = prev.xs.findIndex((x) => Math.abs(x - r.xs[0]) <= 8);
      if (k >= 0 && !findDates(r[0]).length) {
        prev[k] = prev[k] + " " + r[0];
        prev.y = r.y;
        continue;
      }
    }
    out.push(Object.assign(r.slice(), { xs: r.xs, y: r.y, h: r.h }));
  }
  return out;
}

// plain text (pasted notes, .txt files) -> rows
function rowsFromText(text) {
  return String(text)
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((l) => [l]);
}

// ---- 2. dates ---------------------------------------------------------------------------------
function validIso(y, m, d) {
  if (y < 2000 || y > 2100 || m < 1 || m > 12 || d < 1 || d > 31) return null;
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) return null;
  return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

function findDates(line) {
  const out = [];
  let m;
  const numeric = /\b(\d{1,2})\s*[./-]\s*(\d{1,2})\s*[./-]\s*(\d{4}|\d{2})\b/g;
  while ((m = numeric.exec(line))) {
    const y = m[3].length === 2 ? 2000 + +m[3] : +m[3];
    const iso = validIso(y, +m[2], +m[1]); // Indian format: day first
    if (iso) out.push({ iso, index: m.index });
  }
  const dmy = new RegExp(`\\b(\\d{1,2})(?:st|nd|rd|th)?[\\s,.-]*(${MONTH_RE})\\.?[\\s,.-]*(\\d{4})\\b`, "gi");
  while ((m = dmy.exec(line))) {
    const iso = validIso(+m[3], NOTICE_MONTHS[m[2].slice(0, 3).toLowerCase()], +m[1]);
    if (iso) out.push({ iso, index: m.index });
  }
  const mdy = new RegExp(`\\b(${MONTH_RE})\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?,?\\s+(\\d{4})\\b`, "gi");
  while ((m = mdy.exec(line))) {
    const iso = validIso(+m[3], NOTICE_MONTHS[m[1].slice(0, 3).toLowerCase()], +m[2]);
    if (iso) out.push({ iso, index: m.index });
  }
  return out;
}

function fmtDate(iso) {
  const [y, m, d] = iso.split("-");
  return `${+d} ${MONTH_NAMES[+m - 1]} ${y}`;
}

function daysFromToday(iso, now = new Date()) {
  const [y, m, d] = iso.split("-").map(Number);
  return Math.round((Date.UTC(y, m - 1, d) - Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())) / 864e5);
}

function relativeText(iso, now = new Date()) {
  const n = daysFromToday(iso, now);
  if (n === 0) return "today";
  if (n === 1) return "tomorrow";
  if (n === -1) return "yesterday";
  return n > 0 ? `in ${n} days` : `${-n} days ago`;
}

// ---- 3. analysis ------------------------------------------------------------------------------
const NOTICE_TYPES = [
  { id: "exam", label: "Exam schedule / timetable", re: /\b(time\s*-?table|date\s*sheet|examinations?|exams?|practical|mid[\s-]*sem\w*|end[\s-]*sem\w*|admit card)\b/gi },
  { id: "registration", label: "Registration / admission", re: /\b(registration|admission|counsell?ing|enrol?ment|re-?admission|verification)\b/gi },
  { id: "fee", label: "Fee / payment", re: /\b(fees?|fine|payment|deposit|challan|dues)\b/gi },
  { id: "result", label: "Result", re: /\b(results?|declared|grade card|merit list)\b/gi },
  { id: "holiday", label: "Holiday / leave", re: /\b(holidays?|leave|vacation|puja|diwali|chhath|eid|closed)\b/gi },
  { id: "scholarship", label: "Scholarship", re: /\b(scholarships?|stipend)\b/gi },
  { id: "event", label: "Training / placement / event", re: /\b(placement|campus drive|internship|workshop|seminar|training|convocation|fest)\b/gi }
];

function noticeSentences(text) {
  const raw = text
    .split("\u0002")
    .flatMap((seg) => seg.replace(/\s+/g, " ").replace(/([.!?\u0964])\s+(?=[A-Z0-9"'(])/g, "$1\u0001").split("\u0001"));
  const out = [];
  for (const piece of raw) {
    if (out.length && /(?:\b(?:dr|prof|mr|mrs|ms|sr|jr|st|rs|no|vs|etc|dept|govt)|\b[A-Za-z])\.$/i.test(out[out.length - 1])) {
      out[out.length - 1] += " " + piece;
    } else out.push(piece);
  }
  return out.map((x) => x.trim()).filter(Boolean);
}

const HEADER_NOISE = /(government|govt\.? of|department of|bakhtiyarpur college|college of engineering|engineering college|phone|e-?mail|website|www\.|@|fax)/i;

function pickTitle(lines) {
  const subj = lines.find((l) => /^\s*(sub(?:ject)?|re)\s*[:.\-]/i.test(l));
  if (subj) return subj.replace(/^\s*(sub(?:ject)?|re)\s*[:.\-]\s*/i, "").trim().slice(0, 180);
  const named = lines
    .slice(0, 16)
    .find((l) => l.length >= 14 && /[A-Za-z]{4}/.test(l) && !HEADER_NOISE.test(l) && /(notice|notification|circular|order|schedule|time\s*table|result|registration|admission|examination)/i.test(l));
  const any = lines.find((l) => l.length >= 20 && /[A-Za-z]{4}/.test(l) && !HEADER_NOISE.test(l));
  return (named || any || "").slice(0, 180);
}

// rows: array of rows (arrays of cells) from one or more pages
function analyzeNotice(inputRows, pageCount = 1) {
  const rows = mergeWrappedCells(inputRows);
  const lines = rows.map((r) => r.join("  "));
  const fullText = lines.join("\n");
  const result = {
    title: pickTitle(lines),
    type: { id: "general", label: "General notice" },
    ref: "",
    issued: null,
    signatory: "",
    dates: [],
    range: null,
    amounts: [],
    actions: [],
    table: null,
    scanned: fullText.replace(/\s/g, "").length < 40 * Math.max(1, pageCount),
    pages: pageCount
  };

  // kind of notice: keyword score over the title and the first lines
  const head = result.title + "\n" + lines.slice(0, 40).join("\n");
  let best = 0;
  for (const t of NOTICE_TYPES) {
    const n = (head.match(t.re) || []).length;
    if (n > best) {
      best = n;
      result.type = { id: t.id, label: t.label };
    }
  }

  const ref = fullText.match(/(?:\b(?:Lt|Letter|Memo|Ref(?:erence)?)\.?\s*No\.?|\bNo\.)\s*[:.\-]?\s*([A-Za-z0-9][A-Za-z0-9_/.\-]{3,})/i) || fullText.match(/\b(BCE[_ ][A-Za-z0-9_]{4,})\b/);
  if (ref) result.ref = ref[1].replace(/[.,;]+$/, "");

  const tail = lines.slice(-10);
  for (let i = tail.length - 1; i >= 0; i--) {
    const m = tail[i].match(/(Principal(?:\s*in[\s-]*Charge)?|Registrar|Controller of Examinations?|Head of (?:the )?Department|Professor[\s-]*In[\s-]*Charge[^\n]{0,30}|Dean[^\n]{0,24})/i);
    if (m) {
      result.signatory = m[1].replace(/\s+/g, " ").trim();
      break;
    }
  }

  // table: rows with 3+ cells around the date rows (timetables, lists of dates)
  const dateRowIdx = rows.map((r, i) => (r.length >= 3 && findDates(r.join(" ")).length ? i : -1)).filter((i) => i >= 0);
  const tableIdx = new Set();
  if (dateRowIdx.length >= 3) {
    const first = dateRowIdx[0];
    const last = dateRowIdx[dateRowIdx.length - 1];
    let header = null;
    for (let i = first - 1; i >= Math.max(0, first - 3); i--) {
      if (rows[i].length >= 3) {
        header = rows[i];
        tableIdx.add(i);
        break;
      }
    }
    for (let i = first; i <= last; i++) if (rows[i].length >= 2) tableIdx.add(i);
    const body = [...tableIdx].sort((a, b) => a - b).filter((i) => rows[i] !== header).map((i) => rows[i].map((c) => c.slice(0, 120)));
    result.table = { header: header ? header.map((c) => c.slice(0, 120)) : null, rows: body.slice(0, 150) };
  }

  // dates outside the table, plus the overall range of the schedule
  const seen = new Set();
  const allIso = [];
  rows.forEach((r, i) => {
    const line = r.join("  ");
    const found = findDates(line);
    found.forEach((f) => allIso.push(f.iso));
    if (tableIdx.has(i)) return;
    for (const f of found) {
      const key = f.iso + "|" + line;
      if (seen.has(key)) continue;
      seen.add(key);
      const isIssue = i < 14 && /\b(date|dated|dt)\b/i.test(line.slice(Math.max(0, f.index - 12), f.index + 1)) && !/\b(last|exam|from|before|till|upto|up to|by)\b/i.test(line);
      if (isIssue && !result.issued) result.issued = f.iso;
      else result.dates.push({ iso: f.iso, context: line.replace(/\s+/g, " ").trim().slice(0, 140) });
    }
  });
  result.dates.sort((a, b) => (a.iso < b.iso ? -1 : a.iso > b.iso ? 1 : 0));
  if (result.table) {
    const tIso = [];
    for (const i of tableIdx) findDates(rows[i].join(" ")).forEach((f) => tIso.push(f.iso));
    tIso.sort();
    result.range = { from: tIso[0], to: tIso[tIso.length - 1], count: result.table.rows.length };
  }

  // amounts
  const amtSeen = new Set();
  lines.forEach((line) => {
    const re = /(?:Rs\.?|INR|₹)\s*([\d,]+(?:\.\d+)?)\s*(?:\/-|only)?|\b([\d,]{3,})\s*\/-/gi;
    let m;
    while ((m = re.exec(line))) {
      const num = (m[1] || m[2]).replace(/,+$/, "");
      const key = num + "|" + line;
      if (amtSeen.has(key)) continue;
      amtSeen.add(key);
      result.amounts.push({ text: "Rs. " + num, context: line.replace(/\s+/g, " ").trim().slice(0, 140) });
    }
  });
  result.amounts = result.amounts.slice(0, 6);

  // what the reader has to do: sentences containing obligation words (outside the table)
  let prose = "";
  rows.forEach((r, i) => {
    if (tableIdx.has(i)) return;
    const line = r.join(" ");
    // a wrapped line continues the sentence; a short or finished line ends it
    prose += line + (line.length < 70 || /[.!?:;]$/.test(line) ? "\u0002" : " ");
  });
  result.actions = noticeSentences(prose)
    .filter((s) => s.length >= 25 && s.length <= 260 && /\b(should|shall|must|required|directed|requested|advised|instructed|submit|report|collect|deposit|pay|last date|deadline|failing which|compulsory|mandatory|bring)\b/i.test(s))
    .slice(0, 5);

  return result;
}

// ---- 4. showing it ----------------------------------------------------------------------------
function noticeSummaryText(a, name, now = new Date()) {
  const lines = [`📄 ${a.title || name}`];
  const meta = [a.type.label];
  if (a.ref) meta.push("Ref: " + a.ref);
  if (a.issued) meta.push("Issued " + fmtDate(a.issued));
  if (a.signatory) meta.push("Signed by " + a.signatory);
  lines.push(meta.join(" · "));

  if (a.range) {
    lines.push("", `🗂️ Schedule: ${a.range.count} entries from ${fmtDate(a.range.from)} (${relativeText(a.range.from, now)}) to ${fmtDate(a.range.to)}. See the table below.`);
  }
  if (a.dates.length) {
    lines.push("", "📅 Important dates");
    for (const d of a.dates.slice(0, 8)) lines.push(`• ${fmtDate(d.iso)} (${relativeText(d.iso, now)}): ${d.context}`);
    if (a.dates.length > 8) lines.push(`• …and ${a.dates.length - 8} more dates in the document`);
  }
  if (a.amounts.length) {
    lines.push("", "💰 Amounts");
    for (const m of a.amounts.slice(0, 4)) lines.push(`• ${m.text}: ${m.context}`);
  }
  if (a.actions.length) {
    lines.push("", "✅ What you need to do");
    for (const s of a.actions) lines.push(`• ${s}`);
  }
  if (!a.dates.length && !a.range && !a.amounts.length && !a.actions.length) {
    lines.push("", "I could not find clear dates, amounts or instructions in this document. Ask me a question about it, or open the original.");
  }
  lines.push("", "ℹ️ Auto-extracted from the PDF text. Please check it against the original notice before acting.");
  return lines.join("\n");
}

// word-boundary patterns, so "mech" does not match "Fluid Mechanics" in a Civil row
const BRANCH_ALIASES = {
  cse: "cse|computer", cs: "cse|computer", ece: "ece|electronics", eee: "eee|electrical", ee: "eee|electrical",
  civil: "civil", mech: "mech|mechanical", mechanical: "mech|mechanical"
};
const ROMAN = { 1: "i", 2: "ii", 3: "iii", 4: "iv", 5: "v", 6: "vi", 7: "vii", 8: "viii" };

// Keep only table rows that mention the branch / semester asked for.
// matched=false means nothing specific was found, so all rows are returned.
function filterNoticeTable(table, query) {
  if (!table) return { rows: [], matched: false, filters: [] };
  const q = String(query).toLowerCase();
  const filters = [];
  const branches = Object.keys(BRANCH_ALIASES).filter((k) => new RegExp(`\\b${k}\\b`).test(q));
  if (branches.length) filters.push(branches[0].toUpperCase());
  const sm = q.match(/\b([1-8])\s*(?:st|nd|rd|th)?\s*sem(?:ester)?\b/) || q.match(/\bsem(?:ester)?\s*[-:]?\s*([1-8])\b/);
  const sem = sm ? +sm[1] : null;
  if (sem) filters.push(`semester ${sem}`);
  if (!filters.length) return { rows: table.rows, matched: false, filters };

  const semRe = sem ? new RegExp(`\\b${sem}(?:st|nd|rd|th)?\\s*sem|\\bsem(?:ester)?\\s*[-:]?\\s*${sem}\\b|\\b${ROMAN[sem]}\\s*sem|\\bsem(?:ester)?\\s*[-:]?\\s*${ROMAN[sem]}\\b`, "i") : null;
  const rows = table.rows.filter((r) => {
    const text = " " + r.join(" ").toLowerCase() + " ";
    const branchOk = !branches.length || new RegExp(`\\b(?:${BRANCH_ALIASES[branches[0]]})\\b`).test(text);
    return branchOk && (!semRe || semRe.test(text));
  });
  return rows.length ? { rows, matched: true, filters } : { rows: table.rows, matched: false, filters };
}
