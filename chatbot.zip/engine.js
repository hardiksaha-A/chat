// =========================================================
// BCE PATNA AI ASSISTANT v5.1 — TUNED ENSEMBLE ML & PDF RAG
// =========================================================

const DATA_KEY = "bce_v5_dataset";
const DOCS_KEY = "bce_v5_docs";
const CHAT_KEY = "bce_v5_chat";
const FEEDBACK_KEY = "bce_v5_feedback";
const DEMO_KEY = "bce_v5_demo";
const MODEL_CACHE_KEY = "bce_v5_model";
// Training settings. Part of the model-cache key, so changing any of them retrains automatically.
const TRAIN_CFG = { version: 1, lr: 4.5, reg: 0.0003, epochs: 160 };
const THEME_KEY = "bce_pro_theme_v2";

// Collects problems found while loading saved data, shown once after boot.
let bootNotice = "";
let storageWarned = false; // one storage warning per session
let replyPending = false; // blocks double-sends while the bot is "typing"
let cvRunning = false; // held-out accuracy test in progress
let drawerOpener = null; // element to refocus when the drawer closes

let dataset = loadDataset();
let uploadedDocs = sanitizeDocs(loadStorage(DOCS_KEY, []));
let chatHistory = sanitizeChat(loadStorage(CHAT_KEY, []));
let feedbackLog = sanitizeFeedback(loadStorage(FEEDBACK_KEY, []));
let answerSeq = 0; // unique ids for expandable answers

// ML Model State
let vocab = new Map();
let wordVocabSet = new Set();
let wordVocabList = [];
let idf = new Float32Array(0);
let W = [];
let b = new Float32Array(0);
let intentPatternVecs = [];
let topicWordSet = new Set(); // every word that appears in the ML training patterns
let facultyIndex = []; // pre-computed lookup data for the faculty matcher

function loadStorage(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return JSON.parse(JSON.stringify(fallback));
}

// Returns true only if the data was really written (quota / private mode can make it fail)
function saveStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    return false;
  }
}

// Same, but tells the user once if the browser refuses to store anything.
function saveOrWarn(key, value) {
  const ok = saveStorage(key, value);
  if (!ok && !storageWarned) {
    storageWarned = true;
    try {
      showToast("Browser storage is full or blocked: changes may be lost after refresh.");
    } catch (e) {}
  }
  return ok;
}

// =========================================================
// 0. DATA VALIDATION (protects boot, import and saved data)
// =========================================================
const MAX_IMPORT_BYTES = 2 * 1024 * 1024;

// Only plain http(s) links are allowed (blocks javascript:, data:, etc.)
function isSafeUrl(url) {
  if (typeof url !== "string") return false;
  try {
    const u = new URL(url.trim());
    return u.protocol === "http:" || u.protocol === "https:";
  } catch (e) {
    return false;
  }
}

function cleanStringList(list) {
  if (!Array.isArray(list)) return [];
  return list
    .filter((s) => typeof s === "string")
    .map((s) => s.trim())
    .filter(Boolean);
}

function cleanLinks(list) {
  if (!Array.isArray(list)) return [];
  const out = [];
  for (const l of list) {
    if (!l || !isSafeUrl(l.url)) continue;
    const url = l.url.trim();
    const type = l.type === "search" ? "search" : url.toLowerCase().endsWith(".pdf") ? "pdf" : "web";
    const label = typeof l.label === "string" && l.label.trim() ? l.label.trim() : "Open Official Link";
    out.push({ label, url, type });
  }
  return out;
}

// Accepts an array or { intents: [...] }. Never throws.
// Returns { dataset, skipped, errors } containing only items the model can safely train on.
function sanitizeDataset(input) {
  const list = Array.isArray(input) ? input : input && Array.isArray(input.intents) ? input.intents : null;
  const result = { dataset: [], skipped: 0, errors: [] };
  if (!list) {
    result.errors.push("File must be a list of topics (or an object with an \"intents\" list).");
    return result;
  }

  const seenTags = new Set();
  list.forEach((item, i) => {
    const label = `Topic #${i + 1}`;
    const skip = (why) => {
      result.skipped++;
      if (result.errors.length < 5) result.errors.push(`${label}: ${why}`);
    };

    if (!item || typeof item !== "object" || Array.isArray(item)) return skip("not an object.");
    const tag = typeof item.tag === "string" ? item.tag.trim() : "";
    if (!tag) return skip("missing \"tag\".");
    if (seenTags.has(tag)) return skip(`duplicate tag "${tag}".`);

    const patterns = cleanStringList(item.patterns);
    if (!patterns.length) return skip(`"${tag}" has no example questions (patterns).`);
    const responses = cleanStringList(item.responses);
    if (!responses.length) return skip(`"${tag}" has no responses.`);

    seenTags.add(tag);
    const clean = { tag, patterns, responses, next: cleanStringList(item.next), links: cleanLinks(item.links) };
    if (typeof item.title === "string" && item.title.trim()) clean.title = item.title.trim();
    result.dataset.push(clean);
  });

  return result;
}

function hashString(str) {
  let h = 5381;
  for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
  return String(h >>> 0);
}
// Hash of a cleaned dataset (compare cleaned with cleaned, so key order never matters)
function datasetHash(list) {
  return hashString(JSON.stringify(list));
}
function defaultHash() {
  return datasetHash(sanitizeDataset(DEFAULT_DATASET).dataset);
}

// Saves a dataset together with the version of the built-in data it came from.
// custom = true once the user taught/imported something, so we never overwrite it silently.
function persistDataset(list, custom) {
  saveOrWarn(DATA_KEY, list);
  saveStorage(DATA_KEY + "_ver", defaultHash());
  saveStorage(DATA_KEY + "_custom", !!custom);
}

// Loads the saved dataset; falls back to the built-in defaults if it is missing or damaged,
// and keeps it in step when data.js changes.
function loadDataset() {
  const fresh = () => JSON.parse(JSON.stringify(DEFAULT_DATASET));
  try {
    const raw = localStorage.getItem(DATA_KEY);
    if (raw) {
      const res = sanitizeDataset(JSON.parse(raw));
      if (res.dataset.length) {
        let list = res.dataset;
        const notes = [];
        const cur = defaultHash();
        const storedVer = loadStorage(DATA_KEY + "_ver", null);
        let custom = loadStorage(DATA_KEY + "_custom", null);
        if (custom === null) custom = datasetHash(list) !== cur; // data saved by an older version
        if (res.skipped) notes.push(`${res.skipped} damaged saved topic(s) were removed.`);

        const stamped = storedVer === null && !custom; // identical to current defaults, just needs a stamp
        if (storedVer !== cur && !stamped) {
          if (!custom) {
            list = fresh();
            notes.push("Built-in topics were updated to the latest version.");
          } else {
            // The user taught or imported their own topics: never change them silently.
            notes.push("Built-in answers were updated. Open Train Topics and tap Reset to get them (this removes your own topics).");
          }
        }
        if (notes.length || storedVer !== cur) persistDataset(list, custom);
        bootNotice = notes.join(" ");
        return list;
      }
      bootNotice = "Saved topics were damaged: default topics restored.";
    }
  } catch (e) {
    bootNotice = "Saved topics were unreadable: default topics restored.";
  }
  return fresh();
}

// Documents matter more than the model cache (which can be rebuilt), so free it if space runs out
function saveDocs() {
  if (saveStorage(DOCS_KEY, uploadedDocs)) return true;
  try {
    localStorage.removeItem(MODEL_CACHE_KEY);
  } catch (e) {}
  return saveStorage(DOCS_KEY, uploadedDocs);
}

// The PDF library (320 KB) is only loaded when someone actually uploads a PDF
let pdfLibPromise = null;
function loadPdfLib() {
  if (typeof pdfjsLib !== "undefined") return Promise.resolve();
  if (!pdfLibPromise) {
    pdfLibPromise = new Promise((resolve, reject) => {
      const el = document.createElement("script");
      el.src = "lib/pdf.min.js";
      el.onload = resolve;
      el.onerror = () => {
        pdfLibPromise = null;
        reject(new Error('PDF reader library is missing. Keep the "lib" folder next to this page, or paste the text below.'));
      };
      document.head.appendChild(el);
    });
  }
  return pdfLibPromise;
}

function cleanTable(t) {
  if (!t || !Array.isArray(t.rows)) return null;
  const row = (r) => (Array.isArray(r) ? r.filter((c) => typeof c === "string").map((c) => c.slice(0, 120)).slice(0, 12) : []);
  const rows = t.rows.map(row).filter((r) => r.length).slice(0, 150);
  if (!rows.length) return null;
  return { header: Array.isArray(t.header) ? row(t.header) : null, rows };
}

function cleanSummary(s) {
  if (!s || typeof s !== "object") return null;
  const str = (v, n = 200) => (typeof v === "string" ? v.slice(0, n) : "");
  const iso = (v) => (typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v) ? v : null);
  return {
    title: str(s.title),
    type: { id: str(s.type && s.type.id, 20) || "general", label: str(s.type && s.type.label, 60) || "General notice" },
    ref: str(s.ref, 80),
    issued: iso(s.issued),
    signatory: str(s.signatory, 80),
    dates: (Array.isArray(s.dates) ? s.dates : []).filter((d) => d && iso(d.iso)).map((d) => ({ iso: d.iso, context: str(d.context, 160) })).slice(0, 40),
    range: s.range && iso(s.range.from) && iso(s.range.to) ? { from: s.range.from, to: s.range.to, count: Number(s.range.count) || 0 } : null,
    amounts: (Array.isArray(s.amounts) ? s.amounts : []).map((a) => ({ text: str(a && a.text, 40), context: str(a && a.context, 160) })).slice(0, 6),
    actions: (Array.isArray(s.actions) ? s.actions : []).map((a) => str(a, 280)).filter(Boolean).slice(0, 5),
    table: cleanTable(s.table),
    scanned: !!s.scanned,
    pages: Number(s.pages) || 1
  };
}

function sanitizeDocs(list) {
  if (!Array.isArray(list)) return [];
  const docs = [];
  for (const d of list) {
    if (!d || typeof d.name !== "string" || !Array.isArray(d.chunks)) continue;
    const chunks = d.chunks
      .filter((c) => c && typeof c.text === "string" && c.text.trim())
      .map((c) => ({ text: c.text, page: Number.isFinite(c.page) ? c.page : null }));
    if (!chunks.length) continue;
    // ids are placed inside an onclick attribute, so only allow safe characters
    const id = typeof d.id === "string" && /^[\w-]+$/.test(d.id) ? d.id : "doc_" + Date.now() + "_" + docs.length;
    docs.push({ id, name: d.name, chunks, summary: cleanSummary(d.summary), sourceUrl: isSafeUrl(d.sourceUrl) ? d.sourceUrl : "" });
  }
  return docs;
}

function sanitizeFeedback(list) {
  if (!Array.isArray(list)) return [];
  return list.filter((e) => e && typeof e.kind === "string" && typeof e.question === "string").slice(-300);
}

function updateMissCount() {
  const el = document.getElementById("miss-count");
  if (el) el.textContent = feedbackLog.filter((e) => e.kind === "miss" || e.kind === "down").length;
}

// kind: "miss" (bot had no answer), "down" / "up" (user vote)
function logFeedback(entry) {
  const last = feedbackLog[feedbackLog.length - 1];
  if (last && last.kind === entry.kind && last.question === entry.question) return;
  feedbackLog.push({ date: new Date().toISOString(), ...entry });
  if (feedbackLog.length > 300) feedbackLog.shift();
  saveOrWarn(FEEDBACK_KEY, feedbackLog);
  updateMissCount();
}

function downloadFeedback() {
  if (!feedbackLog.length) {
    showToast("Nothing logged yet");
    return;
  }
  const payload = {
    note: "Questions the bot could not answer (miss) or users marked wrong (down). Add them as example questions in Train Topics.",
    entries: feedbackLog
  };
  const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = "bce_chatbot_feedback.json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function sanitizeChat(list) {
  if (!Array.isArray(list)) return [];
  return list
    .filter((m) => m && (m.sender === "user" || m.sender === "bot") && typeof m.text === "string")
    .map((m) => ({
      ...m,
      time: typeof m.time === "string" ? m.time : "",
      links: cleanLinks(m.links),
      table: cleanTable(m.table),
      suggestions: Array.isArray(m.suggestions)
        ? m.suggestions.filter((s) => s && typeof s.label === "string" && typeof s.query === "string")
        : []
    }));
}

// =========================================================
// 1. ONLINE / OFFLINE HYBRID STATUS
// =========================================================
function updateNetworkUI(notify = false) {
  const online = navigator.onLine;
  document.body.classList.toggle("is-offline", !online);
  document.getElementById("net-status").textContent = online
    ? "Online • Official Links & PDF Reader Active"
    : "Offline • Local AI & Indexed Docs Active";
  if (notify) {
    showToast(online ? "Back online — official links unlocked!" : "Offline mode — local AI still active");
  }
}
window.addEventListener("online", () => updateNetworkUI(true));
window.addEventListener("offline", () => updateNetworkUI(true));

// =========================================================
// 2. SPELL CORRECTION (LEVENSHTEIN) & TOKENIZER
// =========================================================
function levenshtein(a, b) {
  const m = a.length;
  const n = b.length;
  if (Math.abs(m - n) > 3) return 99;

  const prev = new Int32Array(n + 1);
  const curr = new Int32Array(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;

  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    const ai = a.charCodeAt(i - 1);
    for (let j = 1; j <= n; j++) {
      const cost = ai === b.charCodeAt(j - 1) ? 0 : 1;
      let v = prev[j] + 1;
      const ins = curr[j - 1] + 1;
      const sub = prev[j - 1] + cost;
      if (ins < v) v = ins;
      if (sub < v) v = sub;
      curr[j] = v;
    }
    for (let j = 0; j <= n; j++) prev[j] = curr[j];
  }
  return prev[n];
}

// Keep letters, combining marks and digits from any script (not just a-z)
const CLEAN_RE = /[^\p{L}\p{M}\p{N}\s]/gu;
const HAS_DEVANAGARI = /[\u0900-\u097F]/;

// Common Hindi (Devanagari) words -> the Roman/Hinglish words the model already knows
const DEVANAGARI_MAP = Object.fromEntries(
  Object.entries({
    "फीस": "fees", "फ़ीस": "fees", "शुल्क": "fees", "हॉस्टल": "hostel", "होस्टल": "hostel", "छात्रावास": "hostel",
    "प्लेसमेंट": "placement", "प्रवेश": "admission", "एडमिशन": "admission", "दाखिला": "admission",
    "कॉलेज": "college", "महाविद्यालय": "college", "परीक्षा": "exam", "रिजल्ट": "result", "परिणाम": "result",
    "छात्रवृत्ति": "scholarship", "स्कॉलरशिप": "scholarship", "पुस्तकालय": "library", "लाइब्रेरी": "library",
    "कैंटीन": "canteen", "मेस": "mess", "बस": "bus", "नोटिस": "notice", "सूचना": "notice", "संपर्क": "contact",
    "प्राचार्य": "principal", "प्रिंसिपल": "principal", "विभाग": "department", "कोर्स": "course", "पाठ्यक्रम": "course",
    "सीट": "seats", "सीटें": "seats", "कटऑफ": "cutoff", "वाईफाई": "wifi", "खेल": "sports", "पता": "address",
    "समय": "timing", "नाम": "name", "क्या": "kya", "कैसे": "kaise", "कितनी": "kitni", "कितना": "kitna",
    "कितने": "kitne", "कब": "kab", "कहाँ": "kahan", "कहां": "kahan", "कौन": "kaun", "है": "hai", "हैं": "hain",
    "का": "ka", "की": "ki", "के": "ke", "में": "mein", "मुझे": "mujhe", "बताओ": "batao", "बताइए": "batao",
    "बताइये": "batao", "चाहिए": "chahiye", "समझाओ": "samjhao", "समझाइए": "samjhao", "समझाएं": "samjhao", "सारांश": "summary", "तारीख": "dates", "तिथि": "dates"
  }).map(([k, v]) => [k.normalize("NFC"), v])
);

// Romanised Hindi words that must never be "spell-corrected" into other words
const HINGLISH_PROTECT = new Set([
  "kitni", "kitna", "kitne", "kaise", "kaisa", "kaisi", "milega", "milegi", "milta", "milti", "hoga", "hogi",
  "hota", "hoti", "kahan", "kaha", "kyun", "kyu", "nahi", "nahin", "karna", "karni", "karein", "kare", "batao",
  "bataiye", "bataye", "chahiye", "chahie", "mujhe", "mera", "meri", "mere", "apka", "aapka", "wala", "wali",
  "wale", "lagega", "lagegi", "lagta", "kijiye", "dijiye", "dena", "lena", "jana", "aana", "padhai", "shuru",
  "khatam", "pehle", "baad", "abhi", "saal", "mahina", "rupay", "paisa", "kaun", "batana", "samay", "tarikh",
  "kab", "kya", "milenge", "milegi", "banta", "banti", "hongi", "honge", "sakta", "sakte", "sakti"
]);

function correctQuery(rawText) {
  const cleaned = rawText.normalize("NFC").toLowerCase().replace(CLEAN_RE, " ").trim();
  if (!cleaned) return { text: "", corrected: false };

  const words = cleaned.split(/\s+/);
  let changed = false;

  const fixedWords = words.map((w) => {
    if (DEVANAGARI_MAP[w]) {
      changed = true;
      return DEVANAGARI_MAP[w];
    }
    if (/[^\x00-\x7f]/.test(w) || HINGLISH_PROTECT.has(w)) return w; // other scripts / Hinglish: leave as typed
    if (SHORTHAND[w]) {
      changed = true;
      return SHORTHAND[w];
    }
    if (wordVocabSet.has(w) || STOPWORDS.has(w) || w.length < 4) return w;

    const maxDist = w.length <= 7 ? 2 : 3;
    let bestWord = w;
    let bestScore = 0;

    for (let i = 0; i < wordVocabList.length; i++) {
      const cand = wordVocabList[i];
      if (cand.length < 4) continue;
      if (w[0] !== cand[0] && (w.length < 6 || cand.length < 6)) continue;

      const d = levenshtein(w, cand);
      if (d <= maxDist) {
        const sim = 1 - d / Math.max(w.length, cand.length);
        if (sim >= 0.66) {
          let prefix = 0;
          while (prefix < w.length && prefix < cand.length && w[prefix] === cand[prefix]) prefix++;
          const score = sim + prefix * 0.03;
          if (score > bestScore) {
            bestScore = score;
            bestWord = cand;
          }
        }
      }
    }
    if (bestWord !== w) changed = true;
    return bestWord;
  });

  return { text: fixedWords.join(" "), corrected: changed };
}

function extractWeightedTokens(text) {
  const cleaned = text.normalize("NFC").toLowerCase().replace(CLEAN_RE, " ").trim();
  const words = cleaned ? cleaned.split(/\s+/) : [];
  const tokenWeights = new Map();
  const add = (tok, weight) => tokenWeights.set(tok, (tokenWeights.get(tok) || 0) + weight);

  const contentWords = words.filter((w) => !STOPWORDS.has(w));
  const hasContent = contentWords.length > 0;

  for (let i = 0; i < words.length; i++) {
    const w = words[i];
    const isStop = STOPWORDS.has(w);
    const wWeight = isStop && hasContent ? 0.15 : 1.5;
    add("w:" + w, wWeight);

    if (i < words.length - 1) {
      const nextStop = STOPWORDS.has(words[i + 1]);
      const bWeight = isStop && nextStop && hasContent ? 0.1 : 1.25;
      add("b:" + w + "_" + words[i + 1], bWeight);
    }

    if (!isStop && w.length >= 4) {
      for (let j = 0; j <= w.length - 3; j++) {
        add("c:" + w.slice(j, j + 3), 0.45);
      }
    }
  }
  return { words, contentWords, tokenWeights };
}

function vectorize(text, isInference = false) {
  const { tokenWeights } = extractWeightedTokens(text);
  if (tokenWeights.size === 0) return [];

  const vec = [];
  let normSq = 0;
  let totalWeight = 0;
  let matchedWeight = 0;

  for (const [tok, w] of tokenWeights.entries()) {
    totalWeight += w;
    if (vocab.has(tok)) {
      matchedWeight += w;
      const idx = vocab.get(tok);
      const val = w * idf[idx];
      vec.push([idx, val]);
      normSq += val * val;
    }
  }

  if (vec.length === 0) return [];
  const norm = Math.sqrt(normSq) || 1;
  const coverage = isInference && totalWeight > 0 ? Math.sqrt(matchedWeight / totalWeight) : 1.0;

  for (let i = 0; i < vec.length; i++) {
    vec[i][1] = (vec[i][1] / norm) * coverage;
  }
  return vec;
}

function dotSparse(vecA, vecB) {
  if (!vecA.length || !vecB.length) return 0;
  let mapB = vecB._map;
  if (!mapB) {
    mapB = new Map(vecB);
    vecB._map = mapB; // cached on the pattern vector (rebuilt on every training)
  }
  let sum = 0;
  for (let i = 0; i < vecA.length; i++) {
    const bVal = mapB.get(vecA[i][0]);
    if (bVal) sum += vecA[i][1] * bVal;
  }
  return sum;
}

function softmax(logits, outProbs) {
  let maxL = -Infinity;
  for (let c = 0; c < logits.length; c++) {
    if (logits[c] > maxL) maxL = logits[c];
  }
  let sum = 0;
  for (let c = 0; c < logits.length; c++) {
    const e = Math.exp(logits[c] - maxL);
    outProbs[c] = e;
    sum += e;
  }
  for (let c = 0; c < logits.length; c++) {
    outProbs[c] /= sum;
  }
}

// =========================================================
// 3. TRAIN ENSEMBLE ML MODEL (LOGISTIC REGRESSION + COSINE)
// =========================================================
// ---- Trained-weights cache: repeat visits skip the ~1 s training run --------------------------
function f32ToB64(arr) {
  const bytes = new Uint8Array(arr.buffer, arr.byteOffset, arr.byteLength);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}
function b64ToF32(b64) {
  const bin = atob(b64);
  const buf = new ArrayBuffer(bin.length);
  const u8 = new Uint8Array(buf);
  for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
  return new Float32Array(buf);
}
// The key covers settings, vocabulary and every training question + label, so any change retrains.
function modelCacheKey(rawSamples, C, V) {
  const sig =
    JSON.stringify(TRAIN_CFG) + "|" + C + "|" + V + "|" + Array.from(vocab.keys()).join(" ") + "|" +
    rawSamples.map((x) => x.label + ":" + x.text).join("\n");
  return hashString(sig) + "-" + sig.length;
}
function saveModelCache(key, C, V) {
  try {
    const flat = new Float32Array(C * V);
    for (let c = 0; c < C; c++) flat.set(W[c], c * V);
    localStorage.setItem(MODEL_CACHE_KEY, JSON.stringify({ key, C, V, W: f32ToB64(flat), b: f32ToB64(b) }));
  } catch (e) {} // it is only a cache: quota problems are fine
}
function loadModelCache(key, C, V) {
  try {
    const raw = localStorage.getItem(MODEL_CACHE_KEY);
    if (!raw) return false;
    const o = JSON.parse(raw);
    if (!o || o.key !== key || o.C !== C || o.V !== V) return false;
    const flat = b64ToF32(o.W);
    const bias = b64ToF32(o.b);
    if (flat.length !== C * V || bias.length !== C || !Number.isFinite(flat[0])) return false;
    W = Array.from({ length: C }, (_, c) => flat.slice(c * V, (c + 1) * V));
    b = bias;
    return true;
  } catch (e) {
    return false;
  }
}

// opts.exclude: Set of pattern numbers to leave out (held-out test); opts.silent: don't touch the UI
function trainModel(opts = {}) {
  const t0 = performance.now();
  const rawSamples = [];
  let patternNo = 0;
  for (let c = 0; c < dataset.length; c++) {
    for (const p of dataset[c].patterns) {
      if (!(opts.exclude && opts.exclude.has(patternNo))) rawSamples.push({ text: p, label: c });
      patternNo++;
    }
  }

  vocab = new Map();
  wordVocabSet = new Set();
  topicWordSet = new Set();
  const df = [];

  for (const f of FACULTY_DIRECTORY) {
    for (const k of f.uniqueKeys) wordVocabSet.add(k);
    // Real names must be in the vocabulary, otherwise the spell-corrector can turn
    // e.g. "rajesh" into "rajeev".
    f.name.toLowerCase().split(/[^a-z]+/).filter(Boolean).forEach((w) => wordVocabSet.add(w));
    for (const p of f.phrases) {
      p.split(/\s+/).forEach((w) => wordVocabSet.add(w));
    }
  }

  for (const s of rawSamples) {
    const { words, tokenWeights } = extractWeightedTokens(s.text);
    for (const w of words) {
      wordVocabSet.add(w);
      topicWordSet.add(w);
    }
    for (const tok of tokenWeights.keys()) {
      if (!vocab.has(tok)) {
        vocab.set(tok, vocab.size);
        df.push(0);
      }
      df[vocab.get(tok)]++;
    }
  }
  wordVocabList = Array.from(wordVocabSet);
  buildFacultyIndex();

  const N = rawSamples.length;
  const V = vocab.size;
  const C = dataset.length;

  idf = new Float32Array(V);
  for (let j = 0; j < V; j++) {
    idf[j] = Math.log((N + 1) / (df[j] + 1)) + 1;
  }

  const samples = rawSamples.map((s) => ({
    vec: vectorize(s.text, false),
    label: s.label
  }));

  intentPatternVecs = Array.from({ length: C }, () => []);
  for (const s of samples) {
    intentPatternVecs[s.label].push(s.vec);
  }

  W = Array.from({ length: C }, () => new Float32Array(V));
  b = new Float32Array(C);

  // held-out test runs (opts.silent) never touch the cache
  const cacheKey = opts.silent ? null : modelCacheKey(rawSamples, C, V);
  const loaded = cacheKey ? loadModelCache(cacheKey, C, V) : false;

  const gradW = Array.from({ length: C }, () => new Float32Array(V));
  const gradB = new Float32Array(C);
  const logits = new Float32Array(C);
  const probs = new Float32Array(C);

  const { lr, reg } = TRAIN_CFG;
  const epochs = loaded ? 0 : TRAIN_CFG.epochs; // cached weights: nothing to learn

  for (let ep = 0; ep < epochs; ep++) {
    for (let c = 0; c < C; c++) {
      gradW[c].fill(0);
      gradB[c] = 0;
    }

    for (let i = 0; i < N; i++) {
      const vec = samples[i].vec;
      const y = samples[i].label;

      for (let c = 0; c < C; c++) {
        let z = b[c];
        const Wc = W[c];
        for (let k = 0; k < vec.length; k++) z += Wc[vec[k][0]] * vec[k][1];
        logits[c] = z;
      }

      softmax(logits, probs);

      for (let c = 0; c < C; c++) {
        const err = (probs[c] - (c === y ? 1 : 0)) / N;
        gradB[c] += err;
        const gWc = gradW[c];
        for (let k = 0; k < vec.length; k++) gWc[vec[k][0]] += err * vec[k][1];
      }
    }

    for (let c = 0; c < C; c++) {
      b[c] -= lr * gradB[c];
      const Wc = W[c];
      const gWc = gradW[c];
      for (let j = 0; j < V; j++) {
        Wc[j] -= lr * (gWc[j] + reg * Wc[j]);
      }
    }
  }

  if (!loaded && cacheKey) saveModelCache(cacheKey, C, V);
  if (opts.silent) return;

  let correct = 0;
  for (let i = 0; i < N; i++) {
    const ranked = predictEnsemble(samples[i].vec);
    if (ranked.length && ranked[0].idx === samples[i].label) correct++;
  }

  document.getElementById("stat-intents").textContent = C;
  document.getElementById("stat-faculty").textContent = FACULTY_DIRECTORY.length;
  document.getElementById("stat-docs").textContent = uploadedDocs.length;
  document.getElementById("stat-acc").textContent = ((correct / N) * 100).toFixed(1) + "%";
  const cvEl = document.getElementById("stat-cv");
  if (cvEl && !cvRunning) cvEl.textContent = "tap to measure";
  document.getElementById("stat-time").textContent = Math.max(1, Math.round(performance.now() - t0)) + "ms" + (loaded ? " (cached)" : "");
}

function modelSnapshot() {
  return { vocab, wordVocabSet, wordVocabList, topicWordSet, idf, W, b, intentPatternVecs, facultyIndex };
}
function modelRestore(m) {
  ({ vocab, wordVocabSet, wordVocabList, topicWordSet, idf, W, b, intentPatternVecs, facultyIndex } = m);
}

// Honest accuracy: K-fold test on questions the model was NOT trained on.
// Runs one fold per timer tick; the full model is restored after every fold so chatting stays safe.
function runHeldOutTest(K = 3) {
  if (cvRunning) return;
  cvRunning = true;
  const out = document.getElementById("stat-cv");
  const items = [];
  dataset.forEach((d, c) => {
    d.patterns.forEach((text, k) => items.push({ label: c, fold: k % K, eligible: d.patterns.length >= 2 }));
  });
  items.forEach((it, i) => (it.no = i));
  const topics = dataset.length;
  let right = 0; // answered directly and correctly
  let helped = 0; // right topic answered directly OR offered among the suggestion buttons
  let total = 0;
  let fold = 0;

  const finish = (label) => {
    cvRunning = false;
    out.textContent = label;
  };
  const step = () => {
    out.textContent = `testing ${fold + 1}/${K}…`;
    setTimeout(() => {
      if (dataset.length !== topics) return finish("tap to measure"); // topics changed meanwhile
      const snap = modelSnapshot();
      const docsBackup = uploadedDocs;
      uploadedDocs = [];
      try {
        trainModel({ silent: true, exclude: new Set(items.filter((x) => x.fold === fold).map((x) => x.no)) });
        let i = 0;
        dataset.forEach((d) =>
          d.patterns.forEach((text) => {
            const it = items[i++];
            if (it.fold === fold && it.eligible) {
              total++;
              const r = getReply(text);
              const tag = dataset[it.label].tag;
              if (r.intent === tag) {
                right++;
                helped++;
              } else if (r.intent === "uncertain" && (r.suggestions || []).some((x) => x.query === dataset[it.label].patterns[0])) {
                helped++;
              }
            }
          })
        );
      } catch (err) {
        console.error("Held-out test failed:", err);
      } finally {
        modelRestore(snap);
        uploadedDocs = docsBackup;
      }
      fold++;
      if (fold < K) step();
      else finish(total ? `${Math.round((right / total) * 100)}% direct · ${Math.round((helped / total) * 100)}% incl. suggestions (${K}-fold)` : "n/a");
    }, 30);
  };
  step();
}

function predictEnsemble(vec) {
  const C = dataset.length;
  if (vec.length === 0) return [];

  const logits = new Float32Array(C);
  const probs = new Float32Array(C);

  for (let c = 0; c < C; c++) {
    let z = b[c];
    const Wc = W[c];
    for (let k = 0; k < vec.length; k++) z += Wc[vec[k][0]] * vec[k][1];
    logits[c] = z;
  }

  softmax(logits, probs);

  const ranked = [];
  for (let c = 0; c < C; c++) {
    let maxSim = 0;
    const pVecs = intentPatternVecs[c];
    for (let m = 0; m < pVecs.length; m++) {
      const s = dotSparse(vec, pVecs[m]);
      if (s > maxSim) maxSim = s;
    }
    // Tuned Ensemble: Cosine similarity boosts matches without dragging down Logistic Regression
    const ensembleScore = Math.max(probs[c], 0.65 * probs[c] + 0.45 * maxSim);
    ranked.push({ idx: c, score: ensembleScore, lrProb: probs[c], cosSim: maxSim });
  }
  ranked.sort((a, b) => b.score - a.score);
  return ranked;
}

// =========================================================
// 4. LAYER 1: DIRECT PRINCIPAL & FACULTY MATCHER
// =========================================================
// Words ignored when comparing a query with faculty names / role phrases
const FACULTY_FILLER = new Set([
  ...STOPWORDS,
  "ms", "sir", "madam", "maam", "mam", "ji", "shri", "sri", "smt",
  "who", "whom", "kaun", "kon", "name", "naam",
  "college", "bce", "patna", "bakhtiyarpur", "current", "present", "our"
]);
// Words that signal "tell me about a person"
const PERSON_CUES = new Set(["who", "kaun", "kon", "about", "tell", "profile", "sir", "madam", "maam", "mam", "dr", "prof", "mr", "mrs", "ms", "ji"]);
// Extra words that are fine to add after a person's name ("amrita sinha research")
const PROFILE_WORDS = new Set([
  "research", "publications", "publication", "qualification", "qualifications", "experience",
  "background", "education", "awards", "honors", "honours", "expertise", "bio", "biography",
  "profile", "subjects", "teaching", "achievements", "papers", "designation", "role",
  "faculty", "teacher", "staff", "member", "lecturer"
]);

function facultyTokens(text) {
  return String(text)
    .toLowerCase()
    .replace(/\bin[\s-]+charge\b/g, "incharge")
    .split(/[^a-z0-9]+/)
    .filter((w) => w.length >= 2)
    .map((w) => SHORTHAND[w] || w);
}

function setsEqual(a, b) {
  if (a.size !== b.size) return false;
  for (const x of a) if (!b.has(x)) return false;
  return true;
}

function buildFacultyIndex() {
  facultyIndex = FACULTY_DIRECTORY.map((f) => {
    const nameList = facultyTokens(f.name.replace(/[^a-zA-Z\s]/g, " ")).filter((w) => w.length >= 3 && !FACULTY_FILLER.has(w));
    const nameTokens = new Set(nameList);
    const aliasTokens = new Set(f.uniqueKeys.filter((k) => k.length >= 3 && !nameTokens.has(k)));
    const selfWords = new Set();
    for (const text of [f.role, f.dept, ...f.phrases]) {
      facultyTokens(text).forEach((w) => selfWords.add(w));
    }
    const phraseSets = f.phrases
      .map((p) => new Set(facultyTokens(p).filter((w) => !FACULTY_FILLER.has(w))))
      .filter((ps) => ps.size);
    return { f, nameList, nameTokens, aliasTokens, selfWords, phraseSets };
  });
}

function facultyChip(e) {
  return { label: e.f.name, query: "tell me about " + e.nameList.join(" ") };
}

// Returns null, or one of:
//   { type: "match", faculty }
//   { type: "ambiguous", candidates, term }   several people fit
//   { type: "suggest", candidates, term }     a name was given that we don't know
function matchFaculty(fixedText) {
  if (!facultyIndex.length) return null;
  const words = facultyTokens(fixedText);
  const content = [...new Set(words.filter((w) => !FACULTY_FILLER.has(w)))];
  if (!content.length) return null;
  const contentSet = new Set(content);

  // A. Role phrases ("who is the principal", "cse hod"): the query must contain the
  //    phrase's key words and nothing else, so extra words never get swallowed.
  for (const e of facultyIndex) {
    if (e.phraseSets.some((ps) => setsEqual(ps, contentSet))) return { type: "match", faculty: e.f };
  }

  // B. Names: score = how many name parts (or spelling variants) appear in the query.
  const scored = [];
  for (const e of facultyIndex) {
    const hit = new Set(content.filter((w) => e.nameTokens.has(w) || e.aliasTokens.has(w)));
    if (hit.size) scored.push({ e, hit, score: hit.size });
  }
  if (!scored.length) return null;
  const top = Math.max(...scored.map((s) => s.score));
  const best = scored.filter((s) => s.score === top);

  const explained = new Set(PROFILE_WORDS);
  best.forEach((s) => {
    s.hit.forEach((w) => explained.add(w));
    s.e.selfWords.forEach((w) => explained.add(w));
  });
  const leftover = content.filter((w) => !explained.has(w));
  // Another topic is mixed in ("anil ... hostel fees") -> let the main model answer.
  if (leftover.some((w) => topicWordSet.has(w))) return null;

  const candidates = best.map((s) => s.e);
  const term = content.join(" ");

  if (top >= 2 || leftover.length === 0) {
    return candidates.length === 1
      ? { type: "match", faculty: candidates[0].f }
      : { type: "ambiguous", candidates, term };
  }
  // One known name part plus unknown words ("anil kapoor"): offer the likely person.
  const looksLikeNameLookup = words.some((w) => PERSON_CUES.has(w)) || content.length <= 2;
  if (looksLikeNameLookup && candidates.length <= 3) return { type: "suggest", candidates, term };
  return null;
}

// =========================================================
// 5. LAYER 2: ON-DEVICE PDF / DOCUMENT RAG SEARCH
// =========================================================
// "explain this notice", "dates in this notice", "exam schedule for cse 4th sem"
function docCommand(fixed, correctedTo) {
  const withSummary = uploadedDocs.filter((d) => d.summary);
  if (!withSummary.length) return null;
  const words = fixed.split(/\s+/).filter(Boolean);
  const docNoun = /\b(notice|pdf|document|doc|file|circular)\b/.test(fixed);
  const explain = /\b(explain|summar(?:y|ise|ize)|simplify|samjhao|samjha)\b/.test(fixed) && (docNoun || (words.length <= 3 && /\b(this|it)\b|^(explain|summary|summarise|summarize)$/.test(fixed)));
  const asksDates = /\b(dates?|deadline|due)\b/.test(fixed) && (docNoun || /\bthis\b/.test(fixed));
  const asksTable = /\b(schedule|timetable|time table|date sheet|exam dates?)\b/.test(fixed);
  if (!explain && !asksDates && !asksTable) return null;

  const tokens = new Set(words);
  const named = withSummary.find((d) => d.name.toLowerCase().split(/[^a-z0-9]+/).filter((t) => t.length > 3 && tokens.has(t)).length >= 2);
  const pool = asksTable && !explain ? withSummary.filter((d) => d.summary.table) : withSummary;
  const doc = named || pool[pool.length - 1];
  if (!doc) return null;
  const a = doc.summary;
  const links = doc.sourceUrl ? [{ label: "Open original notice", url: doc.sourceUrl, type: "pdf" }] : [];
  const out = {
    intent: "pdf_summary",
    confidence: "95.0",
    sourceType: "pdf",
    sourceLabel: "From your document: " + doc.name,
    correctedTo,
    links,
    suggestions: []
  };
  const note = "\n\nℹ️ Auto-extracted from the PDF text. Please check it against the original notice before acting.";

  if (explain) return { ...out, reply: noticeSummaryText(a, doc.name), table: smallTable(a.table) };

  if (asksDates && !asksTable) {
    const lines = [`📅 Dates in "${a.title || doc.name}"`];
    if (a.range) lines.push(`• Schedule: ${fmtDate(a.range.from)} to ${fmtDate(a.range.to)} (${a.range.count} entries). Ask "show the schedule".`);
    for (const d of a.dates.slice(0, 10)) lines.push(`• ${fmtDate(d.iso)} (${relativeText(d.iso)}): ${d.context}`);
    if (lines.length === 1) lines.push("I could not find any dates in this document.");
    return { ...out, reply: lines.join("\n") + note };
  }

  if (!a.table) return { ...out, reply: `"${a.title || doc.name}" has no timetable I could read.` + note };
  const f = filterNoticeTable(a.table, fixed);
  const title = a.title || doc.name;
  const intro = f.matched
    ? `Showing ${f.rows.length} entr${f.rows.length === 1 ? "y" : "ies"} for ${f.filters.join(", ")} from "${title}":`
    : f.filters.length
      ? `I couldn't find ${f.filters.join(" / ")} in the table, so here is the whole schedule from "${title}":`
      : `Here is the schedule from "${title}". Tip: ask "schedule for CSE 4th sem" to filter it.`;
  return { ...out, reply: intro + note, table: smallTable({ header: a.table.header, rows: f.rows }) };
}

function searchUploadedDocs(fixedText) {
  if (!uploadedDocs.length) return null;
  const qWords = fixedText.split(/\s+/).filter((w) => w.length >= 3 && !STOPWORDS.has(w));
  if (!qWords.length) return null;

  let best = null;
  let bestScore = 0;

  const wordRes = new Map(); // one RegExp per query word, not one per chunk
  const getWordRe = (w) => {
    let re = wordRes.get(w);
    if (!re) {
      re = new RegExp("\\b" + w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "g");
      wordRes.set(w, re);
    }
    return re;
  };

  for (const doc of uploadedDocs) {
    for (const chunk of doc.chunks) {
      const lc = chunk.text.toLowerCase();
      let matchedTerms = 0;
      let freqScore = 0;

      for (const w of qWords) {
        if (lc.includes(w)) {
          matchedTerms++;
          const hits = (lc.match(getWordRe(w)) || []).length;
          freqScore += hits > 0 ? Math.min(3, hits) * 1.4 : 0.7;
        }
      }

      if (matchedTerms === 0) continue;
      const coverage = matchedTerms / qWords.length;
      const score = coverage * 0.65 + Math.min(1, freqScore / (qWords.length * 1.5)) * 0.35;

      if (score > bestScore) {
        bestScore = score;
        best = { docName: doc.name, page: chunk.page, text: chunk.text, score };
      }
    }
  }
  return best;
}

function buildSiteSearchLink(query) {
  const trimmed = query.trim();
  const shortLabel = trimmed.length > 26 ? trimmed.slice(0, 26) + "..." : trimmed;
  return {
    label: `Search bcebakhtiyarpur.ac.in for "${shortLabel}"`,
    url: `${OFFICIAL_SITE}/?s=${encodeURIComponent(trimmed)}`,
    type: "search"
  };
}

// =========================================================
// 6. MASTER 3-LAYER ROUTER (TUNED THRESHOLDS)
// =========================================================
function getReply(userText) {
  const fixed = correctQuery(userText);
  const liveSearchLink = buildSiteSearchLink(userText);
  const correctedTo = fixed.corrected ? fixed.text : null;

  // Layer 1: Principal / Professor Profile Lookup
  const fm = matchFaculty(fixed.text);
  if (fm && fm.type === "match") {
    const faculty = fm.faculty;
    const nextSuggestions = (faculty.next || [])
      .map((tag) => {
        const t = dataset.find((d) => d.tag === tag);
        return t ? { label: t.title || t.tag, query: t.patterns[0] } : null;
      })
      .filter(Boolean);

    return {
      reply: `${faculty.name}\n${faculty.role} • ${faculty.dept}\n\n${faculty.bio}`,
      intent: "faculty_profile",
      confidence: "98.0",
      sourceType: "faculty",
      sourceLabel: "Official Faculty Profile",
      correctedTo,
      links: faculty.links || [],
      suggestions: nextSuggestions
    };
  }
  if (fm) {
    const shown = fm.candidates.slice(0, 6);
    const names = shown.map((e) => e.f.name);
    const reply =
      fm.type === "ambiguous"
        ? fm.candidates.length > shown.length
          ? `${fm.candidates.length} faculty members match "${fm.term}". Please include the first name. A few of them:`
          : `More than one faculty member matches "${fm.term}". Which one do you mean?`
        : `I couldn't find a faculty member named "${fm.term}". Did you mean ${names.join(" or ")}?`;
    return {
      reply,
      intent: fm.type === "ambiguous" ? "faculty_ambiguous" : "faculty_suggest",
      confidence: fm.type === "ambiguous" ? "70.0" : "55.0",
      sourceType: "faculty",
      sourceLabel: "Faculty Directory",
      correctedTo,
      links: [],
      suggestions: shown.map(facultyChip)
    };
  }

  // Layer 2: questions about an uploaded notice (explain / dates / schedule)
  const dc = docCommand(fixed.text, correctedTo);
  if (dc) return dc;

  // Layer 2b: Check Uploaded PDF / Document RAG
  const docMatch = searchUploadedDocs(fixed.text);
  const asksForFile = /\b(pdf|file|document|brochure|uploaded|notes|notice)\b/.test(fixed.text);

  // Layer 3: Ensemble ML Intent Classifier
  const vec = vectorize(fixed.text, true);
  const ranked = predictEnsemble(vec);
  const topIntent = ranked.length ? ranked[0] : null;

  if (
    docMatch &&
    ((asksForFile && docMatch.score >= 0.42) ||
      (docMatch.score >= 0.62 && (!topIntent || docMatch.score > topIntent.score + 0.12)))
  ) {
    const pageStr = docMatch.page ? ` (Page ${docMatch.page})` : "";
    return {
      reply: `From "${docMatch.docName}"${pageStr}:\n\n"${docMatch.text}"`,
      intent: "pdf_document_rag",
      confidence: (docMatch.score * 100).toFixed(1),
      sourceType: "pdf-rag",
      sourceLabel: `Inside File: ${docMatch.docName}${pageStr}`,
      correctedTo,
      links: [],
      suggestions: [{ label: "Upload Another PDF", query: "__open_docs__" }]
    };
  }

  // Tuned unknown threshold (0.12)
  if (!topIntent || topIntent.score < 0.12) {
    if (docMatch && docMatch.score >= 0.38) {
      const pageStr = docMatch.page ? ` (Page ${docMatch.page})` : "";
      return {
        reply: `Closest match inside "${docMatch.docName}"${pageStr}:\n\n"${docMatch.text}"`,
        intent: "pdf_document_rag",
        confidence: (docMatch.score * 100).toFixed(1),
        sourceType: "pdf-rag",
        sourceLabel: `Inside File: ${docMatch.docName}${pageStr}`,
        correctedTo,
        links: [liveSearchLink],
        suggestions: []
      };
    }

    const hindiNote = HAS_DEVANAGARI.test(userText)
      ? "I understand Hindi script only for a few common words. Please try typing in English letters, e.g. \"hostel fees kitni hai\".\n\n"
      : "";
    return {
      reply:
        hindiNote +
        "I don't have that exact detail in my built-in database yet. If it's inside a college PDF, upload the PDF via the 'PDFs' button above — or search the live official website below!",
      intent: "unknown",
      confidence: topIntent ? (topIntent.score * 100).toFixed(1) : "0.0",
      correctedTo: null,
      links: [
        liveSearchLink,
        { label: "All Official Notices", url: `${OFFICIAL_SITE}/category/notices/`, type: "web" }
      ],
      suggestions: [
        { label: "Principal Dr. Amrita Sinha", query: "tell me full details about principal dr amrita sinha" },
        { label: "Latest Notices", query: "latest notices nov 2026" },
        { label: "Hostel & Mess Fees", query: "hostel fee structure" }
      ]
    };
  }

  // Tuned uncertain threshold (0.24)
  if (topIntent.score < 0.24) {
    const candidates = ranked
      .slice(0, 3)
      .filter((r) => !["greeting", "thanks", "goodbye"].includes(dataset[r.idx].tag))
      .map((r) => ({
        label: dataset[r.idx].title || dataset[r.idx].tag,
        query: dataset[r.idx].patterns[0]
      }));

    return {
      reply: candidates.length
        ? `I'm not sure I understood. Did you mean "${candidates[0].label}"? Tap the closest topic below, or search the official website.`
        : "I'm not sure I understood. Try rephrasing, or search the official website.",
      intent: "uncertain",
      confidence: (topIntent.score * 100).toFixed(1),
      correctedTo,
      links: [liveSearchLink],
      suggestions: candidates.length ? candidates : [{ label: "B.Tech Courses", query: "courses offered" }]
    };
  }

  const item = dataset[topIntent.idx];
  const reply = item.responses[Math.floor(Math.random() * item.responses.length)];
  const nextSuggestions = (item.next || [])
    .map((nextTag) => {
      const target = dataset.find((d) => d.tag === nextTag);
      return target ? { label: target.title || target.tag, query: target.patterns[0] } : null;
    })
    .filter(Boolean);

  return {
    reply,
    intent: item.tag,
    confidence: Math.min(99.9, topIntent.score * 100).toFixed(1),
    correctedTo,
    links: item.links || [],
    suggestions: nextSuggestions
  };
}

// =========================================================
// 7. ON-DEVICE PDF & TEXT FILE READER
// =========================================================
// Periods that do NOT end a sentence: titles, initials, "Rs.", "etc."
const ABBREV_END = /(?:\b(?:dr|prof|mr|mrs|ms|sr|jr|st|rs|no|vs|etc|eg|ie|fig|vol|approx|dept|univ|govt)|\b[A-Za-z])\.$/i;
const MAX_CHUNK = 360;
const HARD_MAX_PIECE = 500;

function splitSentences(clean) {
  // split after . ! ? or Devanagari danda when followed by a space, then re-join abbreviation splits
  const raw = clean.replace(/([.!?\u0964])\s+/g, "$1\u0001").split("\u0001"); // no lookbehind: works on older Safari
  const out = [];
  for (const piece of raw) {
    if (out.length && ABBREV_END.test(out[out.length - 1])) out[out.length - 1] += " " + piece;
    else out.push(piece);
  }
  return out.map((x) => x.trim()).filter(Boolean);
}

// Break an over-long run of text (e.g. PDF text with no punctuation) at ; , or spaces
function splitLongPiece(piece) {
  const parts = [];
  let rest = piece;
  while (rest.length > HARD_MAX_PIECE) {
    let cut = Math.max(rest.lastIndexOf("; ", MAX_CHUNK), rest.lastIndexOf(", ", MAX_CHUNK), rest.lastIndexOf(" ", MAX_CHUNK));
    if (cut < MAX_CHUNK / 2) cut = rest.indexOf(" ", MAX_CHUNK);
    if (cut <= 0) break;
    parts.push(rest.slice(0, cut + 1).trim());
    rest = rest.slice(cut + 1).trim();
  }
  if (rest) parts.push(rest);
  return parts;
}

function chunkText(rawText, pageNum = null) {
  const clean = rawText.replace(/\s+/g, " ").trim();
  if (!clean) return [];
  const sentences = splitSentences(clean).flatMap((x) => (x.length > HARD_MAX_PIECE ? splitLongPiece(x) : [x]));
  const chunks = [];
  let buf = "";

  for (const s of sentences) {
    if (buf && (buf + " " + s).length > MAX_CHUNK && buf.length > 60) {
      chunks.push({ text: buf, page: pageNum });
      buf = s;
    } else {
      buf = buf ? buf + " " + s : s;
    }
  }
  if (buf) {
    // never lose a short tail: attach it to the previous chunk instead of dropping it
    if (buf.length <= 15 && chunks.length) chunks[chunks.length - 1].text += " " + buf;
    else if (buf.length > 3) chunks.push({ text: buf, page: pageNum });
  }
  return chunks;
}

// Posts a bot message straight into the chat (used for notice summaries)
function postBotMessage(partial) {
  const msg = { sender: "bot", time: getTimeStr(), links: [], suggestions: [], confidence: "95.0", ...partial };
  chatHistory.push(msg);
  saveOrWarn(CHAT_KEY, chatHistory.slice(-40));
  appendMessageDOM(msg);
  return msg;
}

function smallTable(t) {
  return t ? { header: t.header, rows: t.rows.slice(0, 60) } : null;
}

// pages: [{ num, rows }] where rows come from buildRows() or rowsFromText()
function indexNotice(pages, name, opts = {}) {
  const chunks = [];
  pages.forEach((p) => chunks.push(...chunkText(p.rows.map((r) => r.join(" ")).join("\n"), p.num)));
  if (!chunks.length) return null;
  const summary = analyzeNotice(pages.flatMap((p) => p.rows), pages.length);
  const doc = { id: "doc_" + Date.now(), name, chunks, summary, sourceUrl: opts.sourceUrl || "" };
  uploadedDocs.push(doc);
  const saved = saveDocs();
  renderDocList();
  document.getElementById("stat-docs").textContent = uploadedDocs.length;
  postDocSummary(doc, opts.objectUrl);
  return { doc, saved, chunks: chunks.length };
}

function postDocSummary(doc, objectUrl) {
  const links = [];
  const open = doc.sourceUrl || objectUrl;
  if (open) links.push({ label: doc.sourceUrl ? "Open original notice" : "Open the original PDF (this session)", url: open, type: "pdf" });
  const suggestions = [{ label: "Dates only", query: "dates in this notice" }];
  if (doc.summary.table) suggestions.push({ label: "Show the schedule", query: "show the schedule" });
  postBotMessage({
    text: noticeSummaryText(doc.summary, doc.name),
    intent: "pdf_summary",
    sourceType: "pdf",
    sourceLabel: "From your document: " + doc.name,
    links,
    table: smallTable(doc.summary.table),
    suggestions
  });
}

function explainDoc(id) {
  const doc = uploadedDocs.find((d) => d.id === id);
  if (!doc || !doc.summary) return;
  postDocSummary(doc, null);
  closeDrawer();
}

function reportIndexed(res, name, statusEl) {
  if (!res) throw new Error("Nothing readable was found in this file.");
  if (res.saved) {
    statusEl.style.color = "var(--success)";
    statusEl.textContent = `Read "${name}": the explanation is in the chat (${res.chunks} searchable passages).`;
    showToast("Notice read. Summary is in the chat");
  } else {
    statusEl.style.color = "var(--danger)";
    statusEl.textContent = `Read "${name}" for this session only. It is too big to save in the browser, so it will be gone after a refresh. Remove other documents or paste only the key pages.`;
    showToast("Not saved: browser storage is full");
  }
  setTimeout(closeDrawer, 700);
  return res;
}

async function indexPdfBuffer(arrayBuf, name, opts, statusEl) {
  await loadPdfLib();
  pdfjsLib.GlobalWorkerOptions.workerSrc = "lib/pdf.worker.min.js";
  const pdf = await pdfjsLib.getDocument({ data: arrayBuf }).promise;
  const pages = [];
  for (let p = 1; p <= pdf.numPages; p++) {
    const content = await (await pdf.getPage(p)).getTextContent();
    pages.push({ num: p, rows: buildRows(content.items) });
  }
  const letters = pages.reduce((n, p) => n + p.rows.reduce((m, r) => m + r.join("").length, 0), 0);
  if (letters < 20) {
    throw new Error("This PDF is a scanned photo with no selectable text. Paste its key points into the box below to index it!");
  }
  return reportIndexed(indexNotice(pages, name, opts), name, statusEl);
}

async function handleDocUpload(event) {
  const file = event.target.files[0];
  if (!file) return;
  const statusEl = document.getElementById("doc-status");
  statusEl.style.color = "var(--accent)";
  statusEl.textContent = `Reading "${file.name}"...`;
  try {
    if (file.name.toLowerCase().endsWith(".pdf")) {
      await indexPdfBuffer(await file.arrayBuffer(), file.name, { objectUrl: URL.createObjectURL(file) }, statusEl);
    } else {
      const rows = rowsFromText(await file.text());
      if (!rows.length) throw new Error("File is empty.");
      reportIndexed(indexNotice([{ num: null, rows }], file.name), file.name, statusEl);
    }
  } catch (err) {
    statusEl.style.color = "var(--danger)";
    statusEl.textContent = err.message || "Could not read file.";
  }
  event.target.value = "";
}

// Works only when the website allows other pages to read its files (or this page is hosted on it)
async function fetchNoticeFromUrl() {
  const statusEl = document.getElementById("doc-status");
  const url = document.getElementById("doc-url").value.trim();
  const fail = (msg, withLink) => {
    statusEl.style.color = "var(--danger)";
    statusEl.textContent = msg;
    if (withLink && isSafeUrl(url)) {
      statusEl.appendChild(document.createElement("br"));
      const a = document.createElement("a");
      a.href = url;
      a.target = "_blank";
      a.rel = "noopener";
      a.textContent = "Open the PDF, save it, then use Upload above";
      statusEl.appendChild(a);
    }
  };
  if (!isSafeUrl(url) || !url.toLowerCase().startsWith("https://")) return fail("Please paste a full https:// link to a PDF.");
  if (!navigator.onLine) return fail("You are offline. Connect to the internet, or upload the file instead.");
  statusEl.style.color = "var(--accent)";
  statusEl.textContent = "Fetching…";
  try {
    const res = await fetch(url, { mode: "cors" });
    if (!res.ok) return fail(`The website answered with an error (${res.status}).`, true);
    const buf = await res.arrayBuffer();
    if (buf.byteLength > 15 * 1024 * 1024) return fail("That file is larger than 15 MB.");
    if (String.fromCharCode(...new Uint8Array(buf.slice(0, 5))) !== "%PDF-") return fail("That link is not a PDF file.", true);
    const name = decodeURIComponent(url.split("?")[0].split("/").pop() || "notice.pdf");
    await indexPdfBuffer(buf, name, { sourceUrl: url }, statusEl);
    document.getElementById("doc-url").value = "";
  } catch (err) {
    if (err && err.name === "TypeError") {
      fail("The website does not allow other pages to read its files, so I can't fetch this automatically.", true);
    } else fail((err && err.message) || "Could not fetch that link.", true);
  }
}

function addPastedDoc() {
  const title = document.getElementById("paste-title").value.trim() || "Custom Notice / Notes";
  const body = document.getElementById("paste-body").value.trim();
  const statusEl = document.getElementById("doc-status");
  if (body.length < 20) {
    statusEl.style.color = "var(--danger)";
    statusEl.textContent = "Please paste at least one full sentence.";
    return;
  }
  try {
    reportIndexed(indexNotice([{ num: null, rows: rowsFromText(body) }], title), title, statusEl);
    document.getElementById("paste-title").value = "";
    document.getElementById("paste-body").value = "";
  } catch (err) {
    statusEl.style.color = "var(--danger)";
    statusEl.textContent = err.message;
  }
}

function deleteDoc(id) {
  uploadedDocs = uploadedDocs.filter((d) => d.id !== id);
  saveOrWarn(DOCS_KEY, uploadedDocs);
  renderDocList();
  document.getElementById("stat-docs").textContent = uploadedDocs.length;
  showToast("Document removed");
}

function renderDocList() {
  const listEl = document.getElementById("doc-list");
  listEl.innerHTML = "";
  if (!uploadedDocs.length) {
    listEl.innerHTML = `<div style="font-size:12px;color:var(--text-muted);text-align:center;padding:8px;">No uploaded PDFs or files yet.</div>`;
    return;
  }

  uploadedDocs.forEach((d) => {
    const div = document.createElement("div");
    div.className = "doc-item";
    div.innerHTML = `
      <div class="doc-info">
        <div class="doc-name"></div>
        <div class="doc-meta">${d.chunks.length} searchable passages</div>
      </div>
      ${d.summary ? `<button class="del-btn" onclick="explainDoc('${d.id}')">Explain</button>` : ""}
      <button class="del-btn" onclick="deleteDoc('${d.id}')">Remove</button>
    `;
    div.querySelector(".doc-name").textContent = d.name;
    listEl.appendChild(div);
  });
}

// =========================================================
// 8. CHAT UI, VOICE, THEME & DRAWER CONTROLS
// =========================================================
const messagesEl = document.getElementById("messages");
const inputEl = document.getElementById("user-input");

function getTimeStr() {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function getLinkIconSVG(type) {
  if (type === "pdf") {
    return `<svg viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="12" y1="18" x2="12" y2="12"/><polyline points="9 15 12 18 15 15"/></svg>`;
  }
  if (type === "search") {
    return `<svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`;
  }
  return `<svg viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>`;
}

function renderWelcome() {
  const card = document.createElement("div");
  card.className = "welcome-card";
  card.innerHTML = `
    <h2>BCE Patna AI Assistant (v5)</h2>
    <p>Upgraded with <strong>Ensemble ML accuracy</strong>, <strong>${FACULTY_DIRECTORY.length} detailed Principal &amp; Professor profiles</strong>, and a built-in <strong>PDF / Document Reader</strong> so you can ask questions directly from inside downloaded college PDFs.</p>
    <div class="starter-grid">
      <button class="starter-card" onclick="quickAsk('tell me full details about principal dr amrita sinha')">
        <span class="starter-title">Principal Profile</span>
        <span class="starter-sub">Dr. Amrita Sinha bio &amp; research</span>
      </button>
      <button class="starter-card" onclick="quickAsk('tell me about dr anil singh yadav')">
        <span class="starter-title">Faculty Lookup</span>
        <span class="starter-sub">Ask any professor's name</span>
      </button>
      <button class="starter-card" onclick="openDrawer('docs')">
        <span class="starter-title">Ask Inside Any PDF</span>
        <span class="starter-sub">Upload brochure, syllabus or notice</span>
      </button>
      <button class="starter-card" onclick="quickAsk('hostel fee structure')">
        <span class="starter-title">Hostel &amp; Notices</span>
        <span class="starter-sub">2026 fees &amp; live official links</span>
      </button>
    </div>
  `;
  messagesEl.appendChild(card);
}

// Short answer first; the rest sits behind "Show more" so long answers are not a wall of text
function splitAnswer(text) {
  const clean = text.trim();
  const lines = clean.split("\n");
  // bullet / numbered lists scan well, so they get more room before collapsing
  const isList = lines.filter((l) => /^\s*([•\-*]|\d+[.)])\s/.test(l)).length >= 3;
  const limit = isList ? 450 : 200;
  if (clean.length <= (isList ? 700 : 220)) return { head: clean, more: "" };

  // 1) take whole lines while they fit (always at least the first one)
  let head = "";
  let i = 0;
  while (i < lines.length && (!head || (head + "\n" + lines[i]).length <= limit)) {
    head = head ? head + "\n" + lines[i] : lines[i];
    i++;
  }
  let rest = lines.slice(i).join("\n").trim();

  // 2) one very long paragraph: cut at a sentence boundary instead
  if (head.length > limit && !head.includes("\n")) {
    const sents = splitSentences(head);
    let k = 0;
    let cut = "";
    while (k < sents.length && (!cut || (cut + " " + sents[k]).length <= limit)) {
      cut = cut ? cut + " " + sents[k] : sents[k];
      k++;
    }
    rest = (sents.slice(k).join(" ") + (rest ? "\n" + rest : "")).trim();
    head = cut;
  }
  return { head, more: rest };
}

function addAnswerPart(bubble, cls, text) {
  const el = document.createElement("div");
  el.className = cls;
  el.textContent = text;
  bubble.appendChild(el);
  return el;
}

function addCollapsible(bubble, text) {
  if (!text) return;
  const { head, more } = splitAnswer(text);
  if (more.length <= 120) {
    addAnswerPart(bubble, "answer-head", text.trim()); // too little to hide: show it all, formatting intact
    return;
  }
  addAnswerPart(bubble, "answer-head", head);
  const id = "more-" + ++answerSeq;
  const moreEl = addAnswerPart(bubble, "answer-more", more);
  moreEl.id = id;
  moreEl.hidden = true;
  const btn = document.createElement("button");
  btn.className = "more-toggle";
  btn.textContent = "Show more ▾";
  btn.setAttribute("aria-expanded", "false");
  btn.setAttribute("aria-controls", id);
  btn.onclick = () => {
    moreEl.hidden = !moreEl.hidden;
    btn.textContent = moreEl.hidden ? "Show more ▾" : "Show less ▴";
    btn.setAttribute("aria-expanded", String(!moreEl.hidden));
  };
  bubble.appendChild(btn);
}

const KEEP_WHOLE_INTENTS = ["unknown", "uncertain", "error", "faculty_ambiguous", "faculty_suggest"];

function renderAnswerBody(bubble, msg) {
  if (msg.sender !== "bot") {
    addAnswerPart(bubble, "", msg.text);
    return;
  }
  let text = msg.text;
  let note = "";
  const ni = text.indexOf("\n\nℹ️ ");
  if (ni !== -1) {
    note = text.slice(ni + 2).trim();
    text = text.slice(0, ni);
  }

  if (msg.intent === "faculty_profile") {
    const lines = text.split("\n");
    addAnswerPart(bubble, "answer-title", lines[0]);
    if (lines[1]) addAnswerPart(bubble, "answer-sub", lines[1]);
    addCollapsible(bubble, lines.slice(2).join("\n").trim());
  } else if (msg.intent === "pdf_document_rag" && /\n\s*\n/.test(text)) {
    const parts = text.split(/\n\s*\n/);
    addAnswerPart(bubble, "answer-head", parts[0]);
    addAnswerPart(bubble, "answer-quote", parts.slice(1).join("\n\n").replace(/^"|"$/g, ""));
  } else if (KEEP_WHOLE_INTENTS.includes(msg.intent)) {
    addAnswerPart(bubble, "answer-head", text);
  } else {
    addCollapsible(bubble, text);
  }
  if (msg.table) renderNoticeTable(bubble, msg.table);
  if (note) addAnswerPart(bubble, "answer-note", note);
}

function renderNoticeTable(bubble, table) {
  if (!table || !table.rows || !table.rows.length) return;
  const wrap = document.createElement("div");
  wrap.className = "table-wrap";
  const t = document.createElement("table");
  t.className = "notice-table";
  const addRow = (cells, tag) => {
    const tr = document.createElement("tr");
    cells.forEach((c) => {
      const td = document.createElement(tag);
      td.textContent = c;
      tr.appendChild(td);
    });
    t.appendChild(tr);
  };
  if (table.header) addRow(table.header, "th");
  table.rows.forEach((r) => addRow(r, "td"));
  wrap.appendChild(t);
  bubble.appendChild(wrap);
}

function voteOnAnswer(msg, kind, footer) {
  msg.vote = kind;
  footer.querySelectorAll(".vote").forEach((b) => b.classList.toggle("on", b.getAttribute("data-kind") === kind));
  logFeedback({ kind, question: msg.question || "", intent: msg.intent || "", confidence: msg.confidence || "" });
  saveOrWarn(CHAT_KEY, chatHistory.slice(-40));
  showToast(kind === "up" ? "Thanks!" : "Thanks, noted. This helps improve answers");
}

function appendMessageDOM(msg) {
  const row = document.createElement("div");
  row.className = "msg-row " + msg.sender;

  const bubble = document.createElement("div");
  bubble.className = "bubble";

  if (msg.sender === "bot" && msg.sourceLabel) {
    const tag = document.createElement("div");
    tag.className = "source-tag " + (msg.sourceType || "");
    tag.textContent = msg.sourceLabel;
    bubble.appendChild(tag);
  }

  if (msg.sender === "bot" && msg.correctedTo) {
    const note = document.createElement("div");
    note.className = "correction-note";
    note.textContent = `Understood as: "${msg.correctedTo}"`;
    bubble.appendChild(note);
  }

  renderAnswerBody(bubble, msg);

  if (msg.sender === "bot" && msg.links && msg.links.length) {
    const linksWrap = document.createElement("div");
    linksWrap.className = "links-wrap";

    msg.links.forEach((link) => {
      const a = document.createElement("a");
      a.className = "link-card";
      a.href = link.url;
      a.target = "_blank";
      a.rel = "noopener noreferrer";

      const type = link.type || (link.url.toLowerCase().endsWith(".pdf") ? "pdf" : "web");
      const badgeText = type === "pdf" ? "PDF" : type === "search" ? "LIVE" : "SITE";

      a.innerHTML = `${getLinkIconSVG(type)}<span></span><span class="link-badge ${type}">${badgeText}</span>`;
      a.querySelector("span").textContent = link.label;
      a.addEventListener("click", (e) => {
        if (!navigator.onLine) {
          e.preventDefault();
          showToast("Connect to internet to open official link");
        }
      });
      linksWrap.appendChild(a);
    });
    bubble.appendChild(linksWrap);
  }

  row.appendChild(bubble);

  const footer = document.createElement("div");
  footer.className = "msg-footer";

  const timeSpan = document.createElement("span");
  timeSpan.textContent = msg.time;
  footer.appendChild(timeSpan);

  if (msg.sender === "bot") {
    if (msg.intent) {
      const mlSpan = document.createElement("span");
      mlSpan.className = "ml-meta";
      mlSpan.textContent = `• ${msg.intent} (${msg.confidence}%)`;
      footer.appendChild(mlSpan);
    }

    const copyBtn = document.createElement("button");
    copyBtn.className = "mini-action";
    copyBtn.innerHTML = `<svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copy`;
    copyBtn.onclick = () => copyText(msg.text);
    footer.appendChild(copyBtn);

    for (const [kind, icon, label] of [["up", "👍", "This answer helped"], ["down", "👎", "This answer was wrong or unhelpful"]]) {
      const v = document.createElement("button");
      v.className = "mini-action vote" + (msg.vote === kind ? " on" : "");
      v.setAttribute("data-kind", kind);
      v.textContent = icon;
      v.setAttribute("aria-label", label);
      v.setAttribute("title", label);
      v.onclick = () => voteOnAnswer(msg, kind, footer);
      footer.appendChild(v);
    }

    if ("speechSynthesis" in window) {
      const speakBtn = document.createElement("button");
      speakBtn.className = "mini-action";
      speakBtn.innerHTML = `<svg viewBox="0 0 24 24"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg> Listen`;
      speakBtn.onclick = () => speakText(msg.text);
      footer.appendChild(speakBtn);
    }
  }

  row.appendChild(footer);

  if (msg.suggestions && msg.suggestions.length) {
    const sugRow = document.createElement("div");
    sugRow.className = "followup-row";
    msg.suggestions.forEach((s) => {
      const btn = document.createElement("button");
      btn.className = "followup-chip";
      btn.textContent = s.label;
      btn.onclick = () => {
        if (s.query === "__open_docs__") openDrawer("docs");
        else if (s.query.startsWith("__pdf__:")) explainPdfUrl(s.query.slice(8));
        else if (s.query.startsWith("__page__:")) {
          const [, type, id] = s.query.split(":");
          readSitePage(type, id);
        } else quickAsk(s.query);
      };
      sugRow.appendChild(btn);
    });
    row.appendChild(sugRow);
  }

  messagesEl.appendChild(row);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function showTypingBubble() {
  const row = document.createElement("div");
  row.className = "msg-row bot";
  row.id = "typing-indicator";
  row.innerHTML = `<div class="bubble"><div class="typing"><span></span><span></span><span></span></div></div>`;
  messagesEl.appendChild(row);
  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function removeTypingBubble() {
  const el = document.getElementById("typing-indicator");
  if (el) el.remove();
}

// Fees / dates / seat numbers go stale: remind users to double-check them
const FRESHNESS_RE = /₹|\bRs\.?\s?\d|\b20(2[4-9]|3\d)\b/;
const NO_NOTE_INTENTS = ["unknown", "error", "pdf_document_rag", "pdf_summary", "live_notices", "live_page", "faculty_profile", "faculty_ambiguous", "faculty_suggest"];
function withFreshnessNote(res) {
  if (NO_NOTE_INTENTS.includes(res.intent) || !FRESHNESS_RE.test(res.reply)) return res.reply;
  return res.reply + "\n\nℹ️ Fees, dates and seat numbers can change. Please confirm on the official website before acting.";
}

function sendMessage() {
  const text = inputEl.value.trim();
  if (!text || replyPending) return;
  replyPending = true;

  const userMsg = { sender: "user", text, time: getTimeStr() };
  chatHistory.push(userMsg);
  saveOrWarn(CHAT_KEY, chatHistory.slice(-40));
  appendMessageDOM(userMsg);
  inputEl.value = "";

  showTypingBubble();

  setTimeout(() => {
    let res;
    try {
      res = getReply(text);
    } catch (err) {
      console.error("getReply failed:", err);
      res = { reply: "Sorry, something went wrong while answering. Please try again.", intent: "error", confidence: "0.0", links: [], suggestions: [] };
    }
    // live website data (needs internet): explicit requests, or the "latest notices" topic
    const liveReq = detectLiveRequest(text) || (res.intent === "latest_notices" && navigator.onLine ? { kind: "notices" } : null);
    if (liveReq) {
      handleLive(liveReq, text, res.intent === "latest_notices" ? res : null); // the typing bubble stays until the answer arrives
      return;
    }
    removeTypingBubble();
    replyPending = false;
    finishReply(text, res);
  }, 200);
}

function finishReply(text, res) {
  if (res.intent === "latest_notices") res.suggestions = [{ label: "Explain a notice PDF", query: "__open_docs__" }, ...(res.suggestions || [])];
  const botMsg = {
    sender: "bot",
    text: withFreshnessNote(res),
    question: text,
    table: res.table || null,
    time: getTimeStr(),
    intent: res.intent,
    confidence: res.confidence,
    sourceType: res.sourceType,
    sourceLabel: res.sourceLabel,
    correctedTo: res.correctedTo,
    links: res.links,
    suggestions: res.suggestions
  };
  chatHistory.push(botMsg);
  if (res.intent === "unknown" || res.intent === "uncertain") {
    logFeedback({ kind: "miss", question: text, intent: res.intent, confidence: res.confidence });
  }
  saveOrWarn(CHAT_KEY, chatHistory.slice(-40));
  appendMessageDOM(botMsg);
}

function quickAsk(question) {
  if (question === "__open_docs__") {
    openDrawer("docs");
    return;
  }
  inputEl.value = question;
  sendMessage();
}

inputEl.addEventListener("keydown", (e) => {
  // ignore the Enter that confirms an IME / voice-keyboard composition
  if (e.key === "Enter" && !e.isComposing && e.keyCode !== 229) sendMessage();
});

function copyText(text) {
  if (navigator.clipboard) {
    navigator.clipboard.writeText(text).then(() => showToast("Copied to clipboard"));
  }
}

function speakText(text) {
  if (!("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = HAS_DEVANAGARI.test(text) ? "hi-IN" : "en-IN";
  window.speechSynthesis.speak(utter);
}

const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
const micBtn = document.getElementById("mic-btn");

if (!SpeechRec) {
  micBtn.style.display = "none";
} else {
  recognition = new SpeechRec();
  recognition.lang = "en-IN";
  recognition.interimResults = false;
  recognition.onstart = () => micBtn.classList.add("listening");
  recognition.onend = () => micBtn.classList.remove("listening");
  recognition.onerror = () => {
    micBtn.classList.remove("listening");
    showToast("Mic unavailable");
  };
  recognition.onresult = (e) => {
    const best = e.results[0][0];
    inputEl.value = best.transcript;
    // send straight away only when the recogniser is confident; otherwise let the user check first
    if (best.confidence >= 0.8) sendMessage();
    else {
      inputEl.focus();
      showToast("Check what I heard, then press send");
    }
  };
}

function toggleVoiceInput() {
  if (!recognition) return;
  if (micBtn.classList.contains("listening")) {
    recognition.stop();
  } else {
    try {
      recognition.start();
    } catch (e) {}
  }
}

function toggleTheme() {
  const html = document.documentElement;
  const next = html.getAttribute("data-theme") === "dark" ? "light" : "dark";
  html.setAttribute("data-theme", next);
  saveOrWarn(THEME_KEY, next);
  showToast(next === "light" ? "Light mode on" : "Dark mode on");
}

function toggleDemoMode() {
  document.body.classList.toggle("demo-mode");
  const active = document.body.classList.contains("demo-mode");
  saveStorage(DEMO_KEY, active);
  document.getElementById("demo-toggle").classList.toggle("active", active);
  showToast(active ? "ML Info shown (Viva Mode)" : "Clean User Mode");
}

function clearChat() {
  chatHistory = [];
  saveOrWarn(CHAT_KEY, []);
  messagesEl.innerHTML = "";
  renderWelcome();
  showToast("Chat cleared");
}

function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove("show"), 2200);
}

function openDrawer(tab = "docs") {
  switchDrawerTab(tab);
  const d = document.getElementById("drawer");
  drawerOpener = document.activeElement;
  d.removeAttribute("inert");
  d.setAttribute("aria-hidden", "false");
  d.classList.add("open");
  document.getElementById("backdrop").classList.add("open");
  const first = d.querySelector(".drawer-head button");
  if (first) setTimeout(() => first.focus(), 50);
}

function closeDrawer() {
  const d = document.getElementById("drawer");
  d.classList.remove("open");
  document.getElementById("backdrop").classList.remove("open");
  d.setAttribute("inert", "");
  d.setAttribute("aria-hidden", "true");
  if (drawerOpener && drawerOpener.focus) drawerOpener.focus();
  drawerOpener = null;
}

// Escape closes the drawer; Tab stays inside it while it is open
document.addEventListener("keydown", (e) => {
  const d = document.getElementById("drawer");
  if (!d.classList.contains("open")) return;
  if (e.key === "Escape") {
    closeDrawer();
    return;
  }
  if (e.key !== "Tab") return;
  const items = Array.from(d.querySelectorAll('button, input, textarea, select, a[href]')).filter((el) => !el.disabled && el.offsetParent !== null);
  if (!items.length) return;
  const first = items[0];
  const last = items[items.length - 1];
  if (e.shiftKey && document.activeElement === first) {
    e.preventDefault();
    last.focus();
  } else if (!e.shiftKey && document.activeElement === last) {
    e.preventDefault();
    first.focus();
  }
});

function switchDrawerTab(tab) {
  document.getElementById("dtab-docs").classList.toggle("active", tab === "docs");
  document.getElementById("dtab-train").classList.toggle("active", tab === "train");
  document.getElementById("pane-docs").classList.toggle("active", tab === "docs");
  document.getElementById("pane-train").classList.toggle("active", tab === "train");
}

function teachBot() {
  const title = document.getElementById("title-input").value.trim();
  const rawPatterns = document.getElementById("patterns-input").value.trim();
  const responseText = document.getElementById("response-input").value.trim();
  const linkUrl = document.getElementById("link-url-input").value.trim();
  const linkLabel = document.getElementById("link-label-input").value.trim();
  const statusEl = document.getElementById("teach-status");

  if (!title || !rawPatterns || !responseText) {
    statusEl.style.color = "var(--danger)";
    statusEl.textContent = "Please fill in Title, Questions, and Answer.";
    return;
  }

  let tag = title.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  if (!tag) tag = "topic_" + Date.now().toString(36); // e.g. a title written only in Hindi
  const seenPat = new Set();
  const newPatterns = rawPatterns
    .split(",")
    .map((p) => p.trim())
    .filter((p) => {
      const k = p.toLowerCase();
      if (!k || seenPat.has(k)) return false;
      seenPat.add(k);
      return true;
    });
  const newLinks = [];

  if (linkUrl && /^https?:\/\//i.test(linkUrl)) {
    newLinks.push({
      label: linkLabel || "Open Official Link",
      url: linkUrl,
      type: linkUrl.toLowerCase().endsWith(".pdf") ? "pdf" : "web"
    });
  }

  const existing = dataset.find((d) => d.tag === tag);
  if (existing) {
    existing.title = title;
    const known = new Set(existing.patterns.map((p) => p.toLowerCase()));
    existing.patterns.push(...newPatterns.filter((p) => !known.has(p.toLowerCase())));
    if (!existing.responses.includes(responseText)) existing.responses.push(responseText);
    if (newLinks.length) {
      existing.links = existing.links || [];
      existing.links.push(...newLinks);
    }
  } else {
    dataset.push({
      tag,
      title,
      next: ["latest_notices", "contact_info"],
      links: newLinks,
      patterns: newPatterns,
      responses: [responseText]
    });
  }

  persistDataset(dataset, true);
  trainModel();

  document.getElementById("title-input").value = "";
  document.getElementById("patterns-input").value = "";
  document.getElementById("response-input").value = "";
  document.getElementById("link-url-input").value = "";
  document.getElementById("link-label-input").value = "";

  statusEl.style.color = "var(--success)";
  statusEl.textContent = `Trained "${title}"! Close this panel and test it.`;
  showToast("Model retrained live!");
}

function resetDataset() {
  dataset = JSON.parse(JSON.stringify(DEFAULT_DATASET));
  persistDataset(dataset, false);
  trainModel();
  document.getElementById("teach-status").style.color = "var(--accent)";
  document.getElementById("teach-status").textContent = `Reset to ${dataset.length} default topics.`;
  showToast("Dataset reset");
}

function downloadDataset() {
  const blob = new Blob([JSON.stringify({ intents: dataset }, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "bce_patna_dataset_v5.json";
  a.click();
  URL.revokeObjectURL(url);
}

function importDataset(event) {
  const file = event.target.files[0];
  if (!file) return;

  const statusEl = document.getElementById("teach-status");
  const fail = (msg) => {
    statusEl.style.color = "var(--danger)";
    statusEl.textContent = msg;
  };

  event.target.value = "";
  if (file.size > MAX_IMPORT_BYTES) {
    fail("File is too large (max 2 MB).");
    return;
  }

  const reader = new FileReader();
  reader.onerror = () => fail("Could not read the file.");
  reader.onload = (e) => {
    const previous = dataset;
    try {
      let parsed;
      try {
        parsed = JSON.parse(e.target.result);
      } catch (parseErr) {
        throw new Error("This file is not valid JSON.");
      }

      const res = sanitizeDataset(parsed);
      if (!res.dataset.length) {
        throw new Error(res.errors[0] || "No valid topics found in this file.");
      }

      // Train first, save only if training worked, so a bad file can never be persisted.
      dataset = res.dataset;
      trainModel();
      persistDataset(dataset, true);

      statusEl.style.color = "var(--success)";
      statusEl.textContent =
        `Imported ${dataset.length} topics and retrained!` +
        (res.skipped ? ` Skipped ${res.skipped} invalid (${res.errors[0]})` : "");
      showToast("Database imported!");
    } catch (err) {
      // Roll back to the previous working dataset
      dataset = previous;
      try {
        trainModel();
      } catch (rollbackErr) {
        console.error("Rollback failed:", rollbackErr);
      }
      fail((err.message || "Import failed.") + " Your existing topics were kept.");
    }
  };
  reader.readAsText(file);
}

// =========================================================
// 9. BOOT APPLICATION
// =========================================================
const savedTheme = loadStorage(THEME_KEY, "dark");
document.documentElement.setAttribute("data-theme", savedTheme === "light" ? "light" : "dark");
updateNetworkUI(false);
renderDocList();
try {
  trainModel();
} catch (err) {
  // Last line of defence: never leave the app unusable because of bad saved data.
  console.error("Model training failed at startup, restoring defaults:", err);
  dataset = JSON.parse(JSON.stringify(DEFAULT_DATASET));
  persistDataset(dataset, false);
  bootNotice = "Saved topics could not be used — default topics restored.";
  trainModel();
}
document.getElementById("drawer").setAttribute("inert", "");
document.getElementById("drawer").setAttribute("aria-hidden", "true");
if (loadStorage(DEMO_KEY, false)) {
  document.body.classList.add("demo-mode");
  document.getElementById("demo-toggle").classList.add("active");
}
updateMissCount();
const relayBox = document.getElementById("relay-toggle");
if (relayBox) relayBox.checked = relayEnabled();
// keep a fresh saved copy of the notices for offline use
if (navigator.onLine) setTimeout(() => liveLatestNotices(8).catch(() => {}), 1500);
const cvPill = document.getElementById("cv-pill");
cvPill.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    runHeldOutTest();
  }
});
// show the welcome card only for a fresh chat, not on top of restored messages
if (chatHistory.length) chatHistory.forEach(appendMessageDOM);
else renderWelcome();
if (bootNotice) showToast(bootNotice);

// Offline + instant repeat loads (needs http/https; skipped when opened as a plain file)
if ("serviceWorker" in navigator && /^https?:$/.test(location.protocol)) {
  window.addEventListener("load", () => navigator.serviceWorker.register("sw.js").catch(() => {}));
}
