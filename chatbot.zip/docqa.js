// =========================================================
// ON-DEVICE DOCUMENT READER: summary + question answering for uploaded PDFs / text files.
// Pure JavaScript (word statistics, no AI service, no internet needed).
//  - dqMeta:      title + section headings, found while a file is indexed
//  - dqSummary:   picks the most central sentences of a document (TextRank over TF-IDF)
//  - dqAnswer:    finds the exact sentence(s) that answer a question (BM25 + question-type rules)
//  - dqKnownWord: lets the spell-corrector leave words from your PDFs alone
// =========================================================
const DQ_STOP = new Set(("a an the and or but if of to in on at by for with from as is are was were be been being am do does did done " +
  "this that these those it its i me my we our you your he she they them his her their there here what which who whom whose why how " +
  "can could should would will shall may might must about into over under than then so such not no yes any all some more most very " +
  "tell give show please pls kindly also just only me ko ka ki ke hai hain tha the kya mein me se par aur").split(/\s+/));
const DQ_DATE_WORDS = new Set(["last", "date", "dates", "deadline", "when", "till", "until", "due", "by"]);
const DQ_SYN = [
  ["package", "salary", "ctc", "lpa", "pay"],
  ["eligible", "eligibility", "criteria", "qualification", "qualify"],
  ["register", "registration", "apply", "application", "enrol", "enroll"],
  ["fee", "fees", "cost", "charge", "price", "amount"],
  ["recruiter", "company", "companies", "employer"],
  ["contact", "phone", "email", "reach"],
  ["exam", "examination", "test"],
  ["mark", "marks", "score", "grade", "percent", "percentage"],
  ["place", "placed", "placement", "job", "offer"]
];

function dqStem(w) {
  w = w.toLowerCase();
  if (w.length <= 3) return w;
  for (const suf of ["ations", "ation", "ments", "ment", "ities", "ity", "ings", "ing", "ers", "er", "ies", "ied", "ed", "es", "s", "ly", "al"]) {
    if (w.endsWith(suf) && w.length - suf.length >= 3) { w = w.slice(0, -suf.length); break; }
  }
  if (w.length > 3 && w.endsWith("e")) w = w.slice(0, -1);
  return w.slice(0, 6);
}
const DQ_SYN_STEMS = DQ_SYN.map((g) => g.map(dqStem));
function dqWords(text) { return (String(text).toLowerCase().match(/[a-z0-9][a-z0-9.%'-]*/g) || []).map((w) => w.replace(/^[.'-]+|[.'-]+$/g, "")).filter(Boolean); }
function dqStems(text) { return dqWords(text).filter((w) => !DQ_STOP.has(w) && w.length > 1).map(dqStem); }
function dqRelated(a, b) { return a === b || (Math.min(a.length, b.length) >= 4 && (a.startsWith(b) || b.startsWith(a))); }
function dqLev(a, b) {
  const m = a.length, n = b.length; let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) { const cur = [i]; for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; }
  return prev[n];
}

// ---- 1. title + headings, read from the layout rows while the file is indexed -------------------
function dqMeta(pages) {
  const rows = [];
  pages.forEach((p) => p.rows.forEach((r) => { const t = r.join(" ").replace(/\s+/g, " ").trim(); if (t) rows.push(t); }));
  const nWords = (t) => t.split(/\s+/).length;
  let tIdx = rows.slice(0, 8).findIndex((t) => nWords(t) >= 2 && nWords(t) <= 18 && t.length <= 130 && !/[.,;]$/.test(t) && (t.match(/[A-Za-z]/g) || []).length >= 8);
  let title = tIdx >= 0 ? rows[tIdx] : "";
  // a long title wraps onto the next line: join it when the first line stops mid-phrase
  if (tIdx >= 0 && /(\b(of|and|for|the|in|on|to|at|with)|[&\-\u2013,])$/i.test(title) && rows[tIdx + 1] && nWords(rows[tIdx + 1]) <= 8 && !/[.;]$/.test(rows[tIdx + 1])) title = (title + " " + rows[tIdx + 1]).replace(/\s*[-\u2013]\s*$/, "");
  title = title.slice(0, 130);
  const small = new Set(["the", "of", "and", "to", "in", "for", "a", "an", "on", "at", "or", "with", "how"]);
  const headings = [];
  rows.forEach((t, i) => {
    if (title.includes(t) || headings.length >= 20) return;
    const body = t.replace(/:$/, "");
    const words = body.split(/\s+/);
    if (words.length > 8 || body.length > 70 || /[.,;!?]$/.test(body) || /^\d+$/.test(body)) return;
    const alpha = words.filter((w) => /[A-Za-z]/.test(w) && !small.has(w.toLowerCase()));
    if (!alpha.length || alpha.filter((w) => /^[A-Z0-9]/.test(w)).length / alpha.length < 0.75) return;
    const next = rows[i + 1];
    if (next && next.length < body.length * 1.2 && !/:$/.test(t)) return; // a heading is followed by a longer body line
    if (!headings.some((h) => h.toLowerCase() === body.toLowerCase())) headings.push(body);
  });
  return { title, headings };
}

// ---- 2. index of sentences (rebuilt when documents change; never saved) -------------------------
let dqCache = { sig: "", idx: null };
function dqIndex() {
  const sig = uploadedDocs.map((d) => d.id + ":" + d.chunks.length).join("|");
  if (dqCache.sig === sig && dqCache.idx) return dqCache.idx;
  const sents = [], df = new Map(), vocab = new Set(), docWords = new Set();
  uploadedDocs.forEach((doc, di) => {
    const heads = (doc.headings || []).concat(doc.title ? [doc.title] : []).sort((a, b) => b.length - a.length);
    let section = "";
    doc.chunks.forEach((c) => {
      splitSentences(c.text.replace(/\s+/g, " ").trim()).forEach((raw) => {
        let text = raw, again = true;
        while (again) { // headings glue themselves to the start of the next sentence: peel them off
          again = false;
          for (const h of heads) {
            if (text.toLowerCase().startsWith(h.toLowerCase()) && text.length > h.length + 1) {
              if (h !== doc.title) section = h;
              text = text.slice(h.length).replace(/^[\s:.\-–]+/, "");
              again = true; break;
            }
          }
        }
        if (text.length < 3) return;
        const stems = dqStems(text), secStems = dqStems(section);
        sents.push({ doc: di, docName: doc.name, page: c.page, text, section, stems, all: stems.concat(secStems), len: stems.length || 1 });
        dqWords(text).forEach((w) => docWords.add(w));
      });
    });
  });
  sents.forEach((s) => { new Set(s.all).forEach((t) => { df.set(t, (df.get(t) || 0) + 1); vocab.add(t); }); });
  const avg = sents.reduce((n, s) => n + s.len, 0) / (sents.length || 1);
  dqCache = { sig, idx: { sents, df, vocab, avg, N: sents.length, docWords } };
  return dqCache.idx;
}
function dqKnownWord(w) {
  if (!uploadedDocs.length) return false;
  return dqIndex().docWords.has(w);
}
const dqIdf = (ix, t) => Math.log(1 + (ix.N - (ix.df.get(t) || 0) + 0.5) / ((ix.df.get(t) || 0) + 0.5));

// ---- 3. answering a question --------------------------------------------------------------------
function dqAnswer(question, onlyDoc) {
  if (!uploadedDocs.length) return null;
  const ix = dqIndex();
  const raw = question.toLowerCase();
  const wantsDate = /\b(when|last date|deadline|till when|until when|by when|due)\b/.test(raw);
  const wantsNum = /\bhow (many|much|long)\b|\b(percent|percentage|marks|package|fees?|salary|number|count|total|lpa)\b/.test(raw);
  const wantsDef = /\b(what (is|are|does)|define|meaning of|explain|samjhao|kya hota)\b/.test(raw);
  const words = dqWords(raw).filter((w) => !DQ_STOP.has(w) && !DQ_DATE_WORDS.has(w) && !/^(many|much|long)$/.test(w));
  const terms = [];
  for (const w of words) {
    const st = dqStem(w);
    let hits = [...ix.vocab].filter((v) => dqRelated(st, v));
    let weight = 1;
    if (!hits.length) { // synonyms, then typos
      const g = DQ_SYN_STEMS.find((grp) => grp.some((s) => dqRelated(st, s)));
      if (g) { hits = [...ix.vocab].filter((v) => g.some((s) => dqRelated(s, v))); weight = 0.8; }
    }
    if (!hits.length && w.length >= 5) {
      const lim = w.length >= 9 ? 2 : 1;
      hits = [...ix.vocab].filter((v) => Math.abs(v.length - st.length) <= lim && dqLev(st, v) <= lim);
      weight = 0.8;
    }
    terms.push({ w, hits: new Set(hits), weight, idf: hits.length ? Math.max(...hits.map((h) => dqIdf(ix, h))) : 0.5 });
  }
  if (!terms.length) return null;
  const total = terms.reduce((n, t) => n + t.idf, 0);
  const k1 = 1.2, bb = 0.75;
  const scored = [];
  ix.sents.forEach((s, i) => {
    if (onlyDoc != null && s.doc !== onlyDoc) return;
    let bm = 0, cov = 0;
    for (const t of terms) {
      if (!t.hits.size) continue;
      let tf = 0;
      for (const x of s.all) if (t.hits.has(x)) tf++;
      if (!tf) continue;
      cov += t.idf * t.weight;
      bm += t.idf * t.weight * ((tf * (k1 + 1)) / (tf + k1 * (1 - bb + (bb * s.len) / ix.avg)));
    }
    if (!cov) return;
    let conf = Math.min(1, cov / total);
    let score = bm;
    if (wantsDate) { const has = typeof findDates === "function" && findDates(s.text).length; score *= has ? 1.5 : 0.8; if (!has) conf *= 0.8; }
    if (wantsNum) { const has = /\d/.test(s.text); score *= has ? 1.35 : 0.85; if (!has) conf *= 0.85; }
    if (wantsDef) {
      const def = terms.some((t) => new RegExp("\\b" + t.w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "[a-z]*\\b.{0,40}\\b(is|are|means|refers|follows|defined|called)\\b", "i").test(s.text));
      if (def) score *= 1.6;
    }
    scored.push({ i, s, score, conf });
  });
  if (!scored.length) return null;
  scored.sort((a, b) => b.score - a.score);
  const best = scored[0];

  // the question names a whole section ("tell me about eligibility criteria")
  const secHit = (() => {
    const names = [...new Set(ix.sents.map((s) => s.section).filter(Boolean))];
    for (const h of names) {
      const hs = dqStems(h);
      if (terms.every((t) => t.hits.size && hs.some((x) => t.hits.has(x))) && terms.length) {
        const list = ix.sents.filter((s) => s.section === h && (onlyDoc == null || s.doc === onlyDoc));
        if (list.length) return { h, list };
      }
    }
    return null;
  })();
  if (secHit && !wantsDate && !wantsNum) {
    return { kind: "section", section: secHit.h, docName: secHit.list[0].docName, page: secHit.list[0].page, items: secHit.list.slice(0, 6).map((s) => s.text), conf: 0.9 };
  }

  const extras = scored.slice(1, 6).filter((x) => x.s.doc === best.s.doc && x.score >= best.score * 0.6 && x.conf >= 0.5 && x.s.text !== best.s.text).slice(0, 2).sort((a, b) => a.i - b.i);
  return { kind: "sentence", docName: best.s.docName, page: best.s.page, section: best.s.section, text: best.s.text, extras: extras.map((x) => ({ text: x.s.text, page: x.s.page })), conf: best.conf };
}

function dqAnswerReply(a) {
  const where = a.page ? ` (page ${a.page})` : "";
  if (a.kind === "section") return `📑 ${a.section} — from "${a.docName}"${where}:\n\n` + a.items.map((t) => "• " + t).join("\n");
  const sec = a.section ? `${a.section} — ` : "";
  let out = `📄 ${sec}from "${a.docName}"${where}:\n\n${a.text}`;
  if (a.extras.length) out += "\n\nAlso related:\n" + a.extras.map((e) => "• " + e.text).join("\n");
  return out;
}

// ---- 4. summary of a document -------------------------------------------------------------------
function dqIsNotice(doc) {
  const s = doc.summary;
  const head = doc.chunks.slice(0, 2).map((c) => c.text).join(" ").slice(0, 500);
  return !!(s && (s.table || s.ref || s.signatory || s.issued || /\b(notice|circular|notification|office order)\b/i.test(head)));
}

function dqSummary(doc) {
  const di = uploadedDocs.indexOf(doc);
  const ix = dqIndex();
  const sents = ix.sents.filter((s) => s.doc === di && s.text.length >= 35 && s.text.length <= 320 && s.stems.length >= 4).slice(0, 400);
  const N = sents.length;
  const title = doc.title || doc.name.replace(/\.[a-z0-9]+$/i, "").replace(/[_-]+/g, " ");
  const pages = Math.max(1, ...doc.chunks.map((c) => c.page || 1));
  const lines = [`📘 ${title}`, `${pages} page${pages > 1 ? "s" : ""}${doc.headings && doc.headings.length ? " · " + doc.headings.length + " sections" : ""}`];

  if (N) {
    // TextRank: sentences that share many important words with other sentences are central
    const vec = sents.map((s) => { const m = new Map(); s.stems.forEach((t) => m.set(t, (m.get(t) || 0) + dqIdf(ix, t))); return m; });
    const norm = vec.map((m) => Math.sqrt([...m.values()].reduce((n, x) => n + x * x, 0)) || 1);
    const sim = (a, b) => { let d = 0; const [s, l] = vec[a].size < vec[b].size ? [vec[a], vec[b]] : [vec[b], vec[a]]; s.forEach((x, t) => { if (l.has(t)) d += x * l.get(t); }); return d / (norm[a] * norm[b]); };
    const S = Array.from({ length: N }, () => new Float64Array(N));
    for (let a = 0; a < N; a++) for (let b = a + 1; b < N; b++) S[a][b] = S[b][a] = sim(a, b);
    const outW = S.map((row) => row.reduce((n, x) => n + x, 0) || 1);
    let pr = new Float64Array(N).fill(1 / N);
    for (let it = 0; it < 25; it++) {
      const nx = new Float64Array(N).fill(0.15 / N);
      for (let a = 0; a < N; a++) for (let b = 0; b < N; b++) if (S[b][a]) nx[a] += 0.85 * pr[b] * (S[b][a] / outW[b]);
      pr = nx;
    }
    const mx = Math.max(...pr) || 1;
    const rank = sents.map((s, i) => ({ i, score: pr[i] / mx + (i < 3 ? 0.25 - i * 0.06 : 0) + (/\d/.test(s.text) ? 0.08 : 0) })).sort((a, b) => b.score - a.score);
    const pick = [];
    for (const r of rank) {
      if (pick.length >= 5) break;
      if (pick.every((p) => S[p.i][r.i] < 0.6)) pick.push(r);
    }
    pick.sort((a, b) => a.i - b.i);
    lines.push("", "📝 Summary");
    pick.forEach((p) => lines.push("• " + sents[p.i].text));
  } else {
    lines.push("", "I could not find readable sentences in this file. Ask me a question about it, or open the original.");
  }
  if (doc.headings && doc.headings.length) lines.push("", "📑 Sections: " + doc.headings.slice(0, 8).join(" · "));
  const dates = (doc.summary && doc.summary.dates) || [];
  if (dates.length) {
    lines.push("", "📅 Dates in this document");
    dates.slice(0, 4).forEach((d) => lines.push(`• ${fmtDate(d.iso)}: ${d.context}`));
  }
  lines.push("", "ℹ️ The key sentences were picked automatically from the PDF's own text. Please check the original before acting.");
  const suggestions = (doc.headings || []).slice(0, 3).map((h) => ({ label: h, query: "tell me about " + h.toLowerCase() }));
  if (dates.length) suggestions.push({ label: "Dates only", query: "dates in this document" });
  return { text: lines.join("\n"), table: null, suggestions };
}

function docSummaryReply(doc) {
  if (dqIsNotice(doc) || !doc.chunks.length) {
    const sug = [{ label: "Dates only", query: "dates in this notice" }];
    if (doc.summary && doc.summary.table) sug.push({ label: "Show the schedule", query: "show the schedule" });
    return { text: noticeSummaryText(doc.summary, doc.name), table: smallTable(doc.summary.table), suggestions: sug };
  }
  return dqSummary(doc);
}
