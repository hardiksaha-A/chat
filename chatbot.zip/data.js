const OFFICIAL_SITE = "https://bcebakhtiyarpur.ac.in";

// =========================================================
// 1. PRINCIPAL & FACULTY DIRECTORY (27 Verified Profiles)
// =========================================================
const FACULTY_DIRECTORY = [
  {
    name: "Dr. Amrita Sinha",
    role: "Associate Professor & Principal",
    dept: "Department of Electrical & Electronics Engineering (EEE)",
    uniqueKeys: ["amrita"],
    phrases: ["amrita sinha", "principal detail", "principal details", "about principal", "principal profile", "principal qualification", "principal experience", "principal background", "principal message", "who is principal", "principal kon"],
    bio: "Dr. Amrita Sinha is the Principal of Bakhtiyarpur College of Engineering (BCE), Patna and an Associate Professor in the Department of Electrical & Electronics Engineering.\n• Tenure & Experience: Principal at BCE Bakhtiyarpur (Jan 2022 – Present); previously served at Thapar Institute of Engineering & Technology, Patiala (July 2013 – Dec 2021) and NIT Patna.\n• Research Areas: Modeling & intelligent numerical protection of synchronous generators, Artificial Neural Networks (ANN), Fuzzy Logic power quality improvement, hybrid renewable power systems, and transmission line protection.\n• Principal's Message: Encourages students to believe in their abilities and aim for excellence.\n• Official Emails: principal@bcebakhtiyarpur.ac.in | bcebakhtiyarpur@gmail.com",
    links: [
      { label: "Official Profile of Dr. Amrita Sinha", url: "https://bcebakhtiyarpur.ac.in/faculty/dr-amrita-sinha/", type: "web" },
      { label: "Read Principal's Message", url: "https://bcebakhtiyarpur.ac.in/about-us/principals-message/", type: "web" }
    ],
    next: ["professor_incharge_cells", "eee_department"]
  },
  {
    name: "Dr. Anil Singh Yadav",
    role: "Associate Professor & Head of Department (HOD)",
    dept: "Department of Mechanical Engineering",
    uniqueKeys: ["yadav", "anil"],
    phrases: ["anil singh yadav", "anil yadav", "mechanical hod", "mech hod"],
    bio: "Dr. Anil Singh Yadav is Associate Professor and HOD of Mechanical Engineering at BCE Patna.\n• Education: PhD in Mechanical Engineering (2014) and M.Tech in Thermal Engineering (2004) from MANIT Bhopal; B.E. in Mechanical Engineering.\n• Honors & Research: Recognized in Stanford University's 'Top 2% Most Influential Scientists of the World' (2022), inventor of 'Valveless and Camless Internal Combustion Engine' (Patent No. 457316), Editorial Board Member of Scientific Reports (Springer Nature), and reviewed 500+ SCI/Scopus articles.\n• Prior Experience: Taught at LNCT Excellence Bhopal, IES Bhopal, TIT Bhopal, and CSVTU Bhilai.",
    links: [{ label: "Official Profile of Dr. Anil Singh Yadav", url: "https://bcebakhtiyarpur.ac.in/faculty/dr-anil-singh-yadav/", type: "web" }],
    next: ["mech_department", "courses_branches"]
  },
  {
    name: "Prof. Bhawana Singh",
    role: "Assistant Professor & Head of Department (HOD)",
    dept: "Department of Computer Engineering (CSE)",
    uniqueKeys: ["bhawana", "bhavna"],
    phrases: ["bhawana singh", "cse hod", "computer hod", "computer science hod"],
    bio: "Prof. Bhawana Singh is Assistant Professor and Head of Department (HOD) of Computer Engineering at BCE Patna.\n• Subject Expertise: Cryptography and Information Security / Network Security.\n• Resources on Site: Course plans, William Stallings Cryptography materials, and previous year question papers.",
    links: [{ label: "CSE Faculty Directory", url: "https://bcebakhtiyarpur.ac.in/department/computer-engineering/faculty-of-computer-engineering/", type: "web" }],
    next: ["cse_department", "cse_iot_department"]
  },
  {
    name: "Prof. Shahab Uddin Baqar",
    role: "Assistant Professor & Registrar",
    dept: "Department of Electrical & Electronics Engineering (EEE)",
    uniqueKeys: ["baqar", "shahabuddin"],
    phrases: ["shahab uddin baqar", "shahabuddin baqar", "who is registrar", "admission incharge", "anti ragging incharge"],
    bio: "Prof. Shahab Uddin Baqar is Assistant Professor (EEE) and Registrar of BCE Patna.\n• Qualification & Expertise: M.Tech; Subject Expertise in Power Systems.\n• Key Administrative Roles: Professor In-charge of Academic Cell, Admission Cell, and Anti-Ragging Cell.",
    links: [{ label: "Official Administration Directory", url: "https://bcebakhtiyarpur.ac.in/about-us/administration/", type: "web" }],
    next: ["professor_incharge_cells", "anti_ragging"]
  },
  {
    name: "Dr. Rajeev Ranjan",
    role: "Assistant Professor & Training & Placement In-Charge (TPO)",
    dept: "Department of Computer Engineering (CSE)",
    uniqueKeys: ["rajeev"],
    phrases: ["rajeev ranjan", "who is tpo", "placement officer", "placement incharge"],
    bio: "Dr. Rajeev Ranjan is Assistant Professor in Computer Engineering and serves as In-charge of the Training & Placement Cell (TPO) at BCE Patna.\n• Teaching & Course Resources: Software Engineering (Rajib Mall references & course plans) and Fundamentals of Data Communication.\n• Official T&P Email: tpobcebkp@gmail.com",
    links: [
      { label: "Official Profile of Dr. Rajeev Ranjan", url: "https://bcebakhtiyarpur.ac.in/faculty/prof-rajeev-ranjan-2/", type: "web" },
      { label: "Placement Cell Updates", url: "https://bcebakhtiyarpur.ac.in/category/placement/", type: "web" }
    ],
    next: ["placements", "cse_department"]
  },
  {
    name: "Dr. Rajesh Kumar",
    role: "Assistant Professor & Head of Department (HOD)",
    dept: "Department of Civil Engineering",
    uniqueKeys: [],
    phrases: ["rajesh kumar", "civil hod", "civil head of department"],
    bio: "Dr. Rajesh Kumar is Assistant Professor and Head of Department (HOD) of Civil Engineering at BCE Patna.\n• Academic Background: PhD from IIT Delhi, specializing in Structural and Earthquake Engineering.",
    links: [{ label: "Search Dr. Rajesh Kumar on Site", url: "https://bcebakhtiyarpur.ac.in/?s=Rajesh+Kumar", type: "search" }],
    next: ["civil_department", "seat_intake"]
  },
  {
    name: "Dr. Sujit Kumar",
    role: "Assistant Professor",
    dept: "Department of Electrical & Electronics Engineering (EEE)",
    uniqueKeys: ["sujit"],
    phrases: ["sujit kumar"],
    bio: "Dr. Sujit Kumar is Assistant Professor in the Department of Electrical & Electronics Engineering at BCE Patna.\n• Research & Patents (2024–2026): Active researcher publishing in Springer & IEEE journals on Machine Learning & Transformer-based fault classification for rotating machinery, voltage stability in distribution networks, and holder of a Govt. of India Design Patent ('Machine Learning Based Data Processing Device', Design No. 469716-001, Dec 2025).",
    links: [{ label: "Official Profile of Dr. Sujit Kumar", url: "https://bcebakhtiyarpur.ac.in/faculty/dr-sujit-kumar/", type: "web" }],
    next: ["eee_department", "about_bot"]
  },
  {
    name: "Prof. (Dr.) Shahiruddin",
    role: "Associate Professor & Head of Department (HOD)",
    dept: "Department of Electrical & Electronics Engineering (EEE)",
    uniqueKeys: ["shahiruddin"],
    phrases: ["shahiruddin", "eee hod", "electrical hod"],
    bio: "Prof. (Dr.) Shahiruddin is Associate Professor and Head of Department (HOD) of Electrical & Electronics Engineering (EEE) at BCE Patna.",
    links: [{ label: "Search EEE Department on Site", url: "https://bcebakhtiyarpur.ac.in/?s=Shahiruddin", type: "search" }],
    next: ["eee_department", "professor_incharge_cells"]
  },
  {
    name: "Dr. Kumar Amitabh",
    role: "Assistant Professor & Head of Department (HOD, Mathematics)",
    dept: "Department of Applied Science & Humanities",
    uniqueKeys: ["amitabh"],
    phrases: ["kumar amitabh", "applied science hod", "basic science hod", "maths hod"],
    bio: "Dr. Kumar Amitabh is Assistant Professor (Mathematics) and Head of Department (HOD) of Applied Science & Humanities at BCE Patna, overseeing 1st-year core engineering subjects.",
    links: [{ label: "About Applied Science Dept", url: "https://bcebakhtiyarpur.ac.in/department/basic-science/about-basic-science/", type: "web" }],
    next: ["applied_science_department", "rules_attendance_biometric"]
  },
  {
    name: "Prof. Navin Kumar Mishra",
    role: "Professor In-Charge (Examination, Grievance & Boys Hostel Warden)",
    dept: "College Administration, BCE Patna",
    uniqueKeys: ["navin"],
    phrases: ["navin kumar mishra", "navin mishra", "exam controller", "boys hostel warden", "grievance incharge"],
    bio: "Prof. Navin Kumar Mishra handles three major administrative cells at BCE Patna:\n• Examination Cell In-Charge\n• Students Grievance Redressal Cell In-Charge\n• Boys Hostel Warden",
    links: [{ label: "Official Administration Directory", url: "https://bcebakhtiyarpur.ac.in/about-us/administration/", type: "web" }],
    next: ["hostel_allotment_leave", "women_grievance_icc"]
  },
  {
    name: "Dr. Suraj Singh Sisodiya",
    role: "Assistant Professor (English) & Biometric Attendance In-Charge",
    dept: "Department of Applied Science & Humanities",
    uniqueKeys: ["sisodiya", "suraj"],
    phrases: ["suraj singh sisodiya", "suraj sisodiya", "biometric incharge", "english teacher", "english professor"],
    bio: "Dr. Suraj Singh Sisodiya is Assistant Professor (English) in the Department of Applied Science & Humanities and serves as Professor In-Charge of Students Biometric Attendance at BCE Patna.",
    links: [{ label: "Official Administration Directory", url: "https://bcebakhtiyarpur.ac.in/about-us/administration/", type: "web" }],
    next: ["rules_attendance_biometric", "applied_science_department"]
  },
  {
    name: "Prof. Pragya Chaudhary",
    role: "Assistant Professor & Women Helpline In-Charge",
    dept: "Department of Computer Engineering (CSE)",
    uniqueKeys: ["pragya"],
    phrases: ["pragya chaudhary", "pragya choudhary", "women helpline incharge"],
    bio: "Prof. Pragya Chaudhary is Assistant Professor in the Department of Computer Engineering (CSE) and serves as the Professor In-Charge for the Women Helpline at BCE Patna.",
    links: [{ label: "CSE Faculty Directory", url: "https://bcebakhtiyarpur.ac.in/department/computer-engineering/faculty-of-computer-engineering/", type: "web" }],
    next: ["women_grievance_icc", "cse_department"]
  },
  {
    name: "Dr. Ravi Shankar",
    role: "Assistant Professor (Geology) & Student Credit Card (BSCC) In-Charge",
    dept: "Department of Applied Science & Humanities",
    uniqueKeys: [],
    phrases: ["ravi shankar", "student credit card incharge", "bscc incharge", "geology professor"],
    bio: "Dr. Ravi Shankar is Assistant Professor (Geology) in the Department of Applied Science & Humanities and serves as Professor In-Charge for the Bihar Student Credit Card (BSCC) Cell at BCE Patna.",
    links: [{ label: "Official Administration Directory", url: "https://bcebakhtiyarpur.ac.in/about-us/administration/", type: "web" }],
    next: ["scholarships", "applied_science_department"]
  },
  {
    name: "Prof. Shahab Saquib",
    role: "Assistant Professor",
    dept: "Department of Computer Engineering (CSE)",
    uniqueKeys: ["saquib"],
    phrases: ["shahab saquib"],
    bio: "Prof. Shahab Saquib is an Assistant Professor in the Department of Computer Engineering at BCE Patna.",
    links: [{ label: "CSE Faculty Directory", url: "https://bcebakhtiyarpur.ac.in/department/computer-engineering/faculty-of-computer-engineering/", type: "web" }],
    next: ["cse_department"]
  },
  {
    name: "Prof. Ajeet Kumar",
    role: "Assistant Professor",
    dept: "Department of Computer Engineering (CSE)",
    uniqueKeys: ["ajeet"],
    phrases: ["ajeet kumar"],
    bio: "Prof. Ajeet Kumar is an Assistant Professor in the Department of Computer Engineering at BCE Patna.",
    links: [{ label: "CSE Faculty Directory", url: "https://bcebakhtiyarpur.ac.in/department/computer-engineering/faculty-of-computer-engineering/", type: "web" }],
    next: ["cse_department"]
  },
  {
    name: "Prof. Alok Kumar",
    role: "Assistant Professor",
    dept: "Department of Computer Engineering (CSE)",
    uniqueKeys: ["alok"],
    phrases: ["alok kumar"],
    bio: "Prof. Alok Kumar is an Assistant Professor in the Department of Computer Engineering at BCE Patna.",
    links: [{ label: "CSE Faculty Directory", url: "https://bcebakhtiyarpur.ac.in/department/computer-engineering/faculty-of-computer-engineering/", type: "web" }],
    next: ["cse_department"]
  },
  {
    name: "Prof. Afaque Alam",
    role: "Assistant Professor",
    dept: "Department of Computer Engineering (CSE)",
    uniqueKeys: ["afaque"],
    phrases: ["afaque alam"],
    bio: "Prof. Afaque Alam is an Assistant Professor in the Department of Computer Engineering at BCE Patna.",
    links: [{ label: "CSE Faculty Directory", url: "https://bcebakhtiyarpur.ac.in/department/computer-engineering/faculty-of-computer-engineering/", type: "web" }],
    next: ["cse_department"]
  },
  {
    name: "Dr. Shashi Raj",
    role: "Assistant Professor",
    dept: "Department of Computer Engineering (CSE)",
    uniqueKeys: ["shashi"],
    phrases: ["shashi raj"],
    bio: "Dr. Shashi Raj is an Assistant Professor in the Department of Computer Engineering at BCE Patna.",
    links: [{ label: "CSE Faculty Directory", url: "https://bcebakhtiyarpur.ac.in/department/computer-engineering/faculty-of-computer-engineering/", type: "web" }],
    next: ["cse_department"]
  },
  {
    name: "Prof. Shivangi Shekhar",
    role: "Assistant Professor",
    dept: "Department of Computer Engineering (CSE)",
    uniqueKeys: ["shivangi"],
    phrases: ["shivangi shekhar"],
    bio: "Prof. Shivangi Shekhar is an Assistant Professor in the Department of Computer Engineering at BCE Patna.",
    links: [{ label: "CSE Faculty Directory", url: "https://bcebakhtiyarpur.ac.in/department/computer-engineering/faculty-of-computer-engineering/", type: "web" }],
    next: ["cse_department"]
  },
  {
    name: "Prof. Hariom Shankar",
    role: "Assistant Professor",
    dept: "Department of Civil Engineering",
    uniqueKeys: ["hariom"],
    phrases: ["hariom shankar"],
    bio: "Prof. Hariom Shankar is an Assistant Professor in the Department of Civil Engineering at BCE Patna.",
    links: [{ label: "Search on BCE Site", url: "https://bcebakhtiyarpur.ac.in/?s=Hariom+Shankar", type: "search" }],
    next: ["civil_department"]
  },
  {
    name: "Prof. Nishi Bala",
    role: "Assistant Professor",
    dept: "Department of Electrical & Electronics Engineering (EEE)",
    uniqueKeys: ["nishi"],
    phrases: ["nishi bala"],
    bio: "Prof. Nishi Bala is an Assistant Professor in the Department of Electrical & Electronics Engineering (EEE) at BCE Patna.",
    links: [{ label: "Search on BCE Site", url: "https://bcebakhtiyarpur.ac.in/?s=Nishi+Bala", type: "search" }],
    next: ["eee_department"]
  },
  {
    name: "Dr. Nimish Kumar",
    role: "Assistant Professor",
    dept: "Department of Electrical & Electronics Engineering (EEE)",
    uniqueKeys: ["nimish"],
    phrases: ["nimish kumar"],
    bio: "Dr. Nimish Kumar is an Assistant Professor in the Department of Electrical & Electronics Engineering (EEE) at BCE Patna.",
    links: [{ label: "Search on BCE Site", url: "https://bcebakhtiyarpur.ac.in/?s=Nimish+Kumar", type: "search" }],
    next: ["eee_department"]
  },
  {
    name: "Dr. Om Prakash Gujela",
    role: "Assistant Professor",
    dept: "Department of Electrical & Electronics Engineering (EEE)",
    uniqueKeys: ["gujela"],
    phrases: ["om prakash gujela", "op gujela"],
    bio: "Dr. Om Prakash Gujela is an Assistant Professor in the Department of Electrical & Electronics Engineering (EEE) at BCE Patna.",
    links: [{ label: "Search on BCE Site", url: "https://bcebakhtiyarpur.ac.in/?s=Gujela", type: "search" }],
    next: ["eee_department"]
  },
  {
    name: "Prof. Harendra Kumar",
    role: "Assistant Professor (Chemistry)",
    dept: "Department of Applied Science & Humanities",
    uniqueKeys: ["harendra"],
    phrases: ["harendra kumar", "chemistry professor"],
    bio: "Prof. Harendra Kumar is an Assistant Professor (Chemistry) in the Department of Applied Science & Humanities at BCE Patna.",
    links: [{ label: "About Applied Science Dept", url: "https://bcebakhtiyarpur.ac.in/department/basic-science/about-basic-science/", type: "web" }],
    next: ["applied_science_department"]
  },
  {
    name: "Dr. Alka Kumari",
    role: "Assistant Professor (Mathematics)",
    dept: "Department of Applied Science & Humanities",
    uniqueKeys: ["alka"],
    phrases: ["alka kumari"],
    bio: "Dr. Alka Kumari is an Assistant Professor (Mathematics) in the Department of Applied Science & Humanities at BCE Patna.",
    links: [{ label: "About Applied Science Dept", url: "https://bcebakhtiyarpur.ac.in/department/basic-science/about-basic-science/", type: "web" }],
    next: ["applied_science_department"]
  },
  {
    name: "Dr. Priti Kumari",
    role: "Assistant Professor (Mathematics)",
    dept: "Department of Applied Science & Humanities",
    uniqueKeys: ["priti"],
    phrases: ["priti kumari"],
    bio: "Dr. Priti Kumari is an Assistant Professor (Mathematics) in the Department of Applied Science & Humanities at BCE Patna.",
    links: [{ label: "About Applied Science Dept", url: "https://bcebakhtiyarpur.ac.in/department/basic-science/about-basic-science/", type: "web" }],
    next: ["applied_science_department"]
  },
  {
    name: "Dr. Anupama",
    role: "Assistant Professor (Mathematics)",
    dept: "Department of Applied Science & Humanities",
    uniqueKeys: ["anupama"],
    phrases: ["dr anupama"],
    bio: "Dr. Anupama is an Assistant Professor (Mathematics) in the Department of Applied Science & Humanities at BCE Patna.",
    links: [{ label: "About Applied Science Dept", url: "https://bcebakhtiyarpur.ac.in/department/basic-science/about-basic-science/", type: "web" }],
    next: ["applied_science_department"]
  }
];

// =========================================================
// 2. CORE INTENT DATASET (43 BCE PATNA TOPICS)
// =========================================================
const DEFAULT_DATASET = [
  {
    tag: "greeting", title: "Say Hello", next: ["latest_notices", "about_college"],
    links: [
      { label: "Official Website", url: "https://bcebakhtiyarpur.ac.in/", type: "web" },
      { label: "Latest Notices Board", url: "https://bcebakhtiyarpur.ac.in/category/notices/", type: "web" }
    ],
    patterns: ["hi", "hello", "hey", "good morning", "good afternoon", "good evening", "namaste", "hii bot", "hello bce bot", "kaise ho"],
    responses: [
      "Hello! Welcome to BCE Patna AI Assistant v5. Ask me about any professor or the Principal, latest notices, hostel fees, admissions — or upload a PDF via the 'PDFs' button to search inside it!",
      "Hi there! I am the Bakhtiyarpur College of Engineering (BCE) Patna Assistant. How can I help you today?"
    ]
  },
  {
    tag: "latest_notices", title: "Latest Notices (Nov 2026)", next: ["exams_notices", "hostel_allotment_leave"],
    links: [
      { label: "Open Live Notices Board", url: "https://bcebakhtiyarpur.ac.in/category/notices/", type: "web" },
      { label: "Official Homepage", url: "https://bcebakhtiyarpur.ac.in/", type: "web" }
    ],
    patterns: ["latest notices", "recent updates bce patna", "new notice nov 2026", "what are the latest announcements", "nats final result notice", "2026 30 registration notice", "4th semester revised timetable", "6th semester practical exam notice", "problem solving camp notice", "naya notice kya hai"],
    responses: ["Recent Official Notices on bcebakhtiyarpur.ac.in (Oct–Nov 2026):\n• 22 Nov 2026: Final result of NATS (BCE_NATS_2026_37)\n• 19 Nov 2026: Registration of 2026–30 & 2026–29 (LE) (BCE_26_ACAD_701)\n• 19 Nov 2026: Revised timetable of 4th semester\n• 17 Nov 2026: 6th semester practical exam\n• 11 Nov 2026: B.Tech 4th sem & 4th sem (old) practical exam\n• 05 Nov 2026: All Hostel leave notice\n• 31 Oct 2026: 3-day Problem Solving Camp\n• 27 Oct 2026: Boys Hostel-1 allotment\n• 26 Oct 2026: 1st & 8th sem supplementary exam results"]
  },
  {
    tag: "about_college", title: "About BCE Patna", next: ["courses_branches", "location"],
    links: [
      { label: "BCE Patna Official Site", url: "https://bcebakhtiyarpur.ac.in/", type: "web" },
      { label: "Watch Campus Tour Video", url: "https://bcebakhtiyarpur.ac.in/video/bce-patna-campus-tour-official-video/", type: "web" }
    ],
    patterns: ["tell me about bce patna", "what is bce patna", "about bakhtiyarpur college of engineering", "when was bce established", "college history", "is bce a government college", "bce kaisa college hai", "government college hai kya", "old iit patna campus"],
    responses: ["Bakhtiyarpur College of Engineering (BCE), Patna is a Government Engineering College under the Department of Science, Technology and Technical Education (DSTTE), Govt. of Bihar. It started its first academic session in 2016 from the old IIT Patna campus at Patliputra Colony and shifted to its permanent Bakhtiyarpur campus in 2020."]
  },
  {
    tag: "college_stats", title: "Campus Numbers", next: ["clubs_societies", "campus_facilities"],
    links: [{ label: "Official Homepage", url: "https://bcebakhtiyarpur.ac.in/", type: "web" }],
    patterns: ["how many students are in bce patna", "number of faculty and staff", "college statistics", "how many departments and clubs", "alumni network size", "kitne students hai bce me", "total faculty count"],
    responses: ["According to the official BCE Patna website, the institute has 1,000+ students, 100+ faculty & staff, 6 departments, 12+ clubs & societies, 500+ alumni, and 50+ projects."]
  },
  {
    tag: "vision_mission", title: "Vision & Mission", next: ["about_college", "affiliation"],
    links: [{ label: "Vision & Mission Page", url: "https://bcebakhtiyarpur.ac.in/about-us/vision-mission/", type: "web" }],
    patterns: ["what is the vision of bce patna", "college mission statement", "vision and mission of bce", "goals of bakhtiyarpur college of engineering", "college motto"],
    responses: ["BCE Patna's Vision is to be a premier institute providing excellence in education, research, and development to create potential innovators and leaders serving society and the nation. Its Mission emphasizes academia-industry collaborative projects and nurturing ethics, innovation, and entrepreneurship."]
  },
  {
    tag: "affiliation", title: "Affiliation & Approval", next: ["courses_branches", "admission_process"],
    links: [{ label: "BEU Patna University Portal", url: "https://beu-bih.ac.in/", type: "web" }],
    patterns: ["which university is bce affiliated to", "is bce aicte approved", "college affiliation", "beu patna affiliation", "aku bihar engineering university", "is bce approved by government", "degree valid hai kya"],
    responses: ["BCE Patna is approved by AICTE (All India Council for Technical Education), New Delhi, and is affiliated with Bihar Engineering University (BEU), Patna (previously affiliated with Aryabhatta Knowledge University, AKU)."]
  },
  {
    tag: "location", title: "Campus Address & Route", next: ["contact_info", "hostel_mess"],
    links: [{ label: "Open in Google Maps", url: "https://www.google.com/maps/search/?api=1&query=Bakhtiyarpur+College+of+Engineering+Patna", type: "web" }],
    patterns: ["where is bce patna located", "college address", "location of bakhtiyarpur college of engineering", "how far is bce from railway station", "campus location", "pin code of bce patna", "bce patna kaha hai", "station se kitna dur hai", "how to reach campus"],
    responses: ["BCE Patna is located at Champapur, Dedaur, Bakhtiyarpur, Patna, Bihar - 803212, about 3.5 km from Bakhtiyarpur Junction railway station."]
  },
  {
    tag: "courses_branches", title: "B.Tech Courses & Branches", next: ["seat_intake", "admission_process"],
    links: [
      { label: "Official Syllabus Page", url: "https://bcebakhtiyarpur.ac.in/academics/syllabus/", type: "web" },
      { label: "Admission Page", url: "https://bcebakhtiyarpur.ac.in/academics/admission/", type: "web" }
    ],
    patterns: ["what courses are offered", "btech branches in bce patna", "which departments are available", "list of branches", "is cse available", "kon kon sa branch hai", "courses available", "all engineering departments"],
    responses: ["BCE Patna offers 4-year B.Tech programs across:\n• Civil Engineering\n• Computer Science & Engineering (CSE)\n• CSE (Internet of Things - IoT)\n• Electrical & Electronics Engineering (EEE)\n• Mechanical Engineering\n• Fire Technology & Safety Engineering\n• Mathematics & Computing\nPlus the Department of Applied Science & Humanities for 1st-year core subjects."]
  },
  {
    tag: "seat_intake", title: "Branch-Wise Seat Intake", next: ["admission_process", "fees"],
    links: [
      { label: "Official Admission Details", url: "https://bcebakhtiyarpur.ac.in/academics/admission/", type: "web" },
      { label: "BCECEB Counselling Portal", url: "https://bceceboard.bihar.gov.in/", type: "web" }
    ],
    patterns: ["how many seats are there in each branch", "seat intake in bce patna", "cse seats in bce", "civil engineering intake", "fire technology seats", "lateral entry seats", "tfw seats", "kitna seat hai", "total intake"],
    responses: ["B.Tech seat intake at BCE Patna:\n• Civil: 90 (+ 4 TFW + 9 LE)\n• CSE: 60 (+ 3 TFW + 6 LE)\n• CSE (IoT): 60 (+ 3 TFW + 6 LE)\n• EEE: 60 (+ 3 TFW + 6 LE)\n• Mechanical: 60 (+ 3 TFW + 6 LE)\n• Mathematics & Computing: 60 (+ 3 TFW + 6 LE)\n• Fire Technology & Safety: 30 (+ 2 TFW + 3 LE)"]
  },
  {
    tag: "admission_process", title: "Admission Process", next: ["admission_documents", "fees"],
    links: [
      { label: "BCE Admission Page", url: "https://bcebakhtiyarpur.ac.in/academics/admission/", type: "web" },
      { label: "BCECEB UGEAC Portal", url: "https://bceceboard.bihar.gov.in/", type: "web" }
    ],
    patterns: ["how to get admission in bce patna", "admission process", "how to apply for btech", "is jee main required", "ugeac counselling process", "lateral entry admission", "bcece le exam", "admission kaise hota hai", "eligibility criteria"],
    responses: ["B.Tech admission at BCE Patna is based on JEE Main rank through UGEAC counselling by BCECEB, Bihar (10+2 with Physics & Maths required). Diploma holders can enter 2nd year via BCECE (LE). Final admission is confirmed offline after document verification at campus."]
  },
  {
    tag: "admission_documents", title: "Admission Documents & Forms", next: ["admission_process", "fees"],
    links: [
      { label: "Medical Certificate Form", url: "https://bcebakhtiyarpur.ac.in/wp-content/uploads/2024/07/BCE_MEDICAL-CERTIFICATE.pdf", type: "pdf" },
      { label: "Admission Instructions", url: "https://bcebakhtiyarpur.ac.in/academics/admission/", type: "web" }
    ],
    patterns: ["documents required for admission", "what documents to bring for counselling", "admission document verification list", "is transfer certificate required", "medical certificate pdf", "admission me kya document lagta hai", "provisional admission documents"],
    responses: ["Documents required for offline verification at BCE Patna:\n• 10th & 12th Mark Sheets and Passing Certificates\n• JEE Main Scorecard & UGEAC Allotment Letter\n• Transfer Certificate / CLC & Character Certificate\n• Medical Certificate (official PDF linked below)\n• Category / EWS / Income Certificate (if applicable)\n• Photo ID Proof & Passport-size Photographs"]
  },
  {
    tag: "fees", title: "Academic Fee Structure", next: ["hostel_fee", "scholarships"],
    links: [
      { label: "Official Admission & Fee Info", url: "https://bcebakhtiyarpur.ac.in/academics/admission/", type: "web" },
      { label: "Check Latest Fee Notices", url: "https://bcebakhtiyarpur.ac.in/category/notices/", type: "web" }
    ],
    patterns: ["what is the academic fee structure", "btech fees in bce patna", "college tuition fee per year", "semester fee kitna hai", "total fees for 4 years", "college fees kitna lagta hai", "is bce affordable"],
    responses: ["As a Bihar Government engineering college, BCE Patna academic fees are heavily subsidized (approx. ₹21,000–₹25,000/year excluding hostel/mess):\n• Govt. Tuition Fee: nominal (~₹120/year)\n• Institutional / Development Fee: ~₹10,000/year\n• BEU Registration & Exam Fees: ~₹11,000–₹13,000/year"]
  },
  {
    tag: "hostel_fee", title: "Hostel & Mess Fees", next: ["hostel_mess", "hostel_allotment_leave"],
    links: [
      { label: "Official Hostel Fee Notice", url: "https://bcebakhtiyarpur.ac.in/notice-regarding-hostel-fee-of-boys-and-girls-hostel/", type: "web" },
      { label: "Hostel Undertaking & Rules", url: "https://bcebakhtiyarpur.ac.in/wp-content/uploads/2025/07/Adobe-Scan-26-Jul-2025-1.pdf", type: "pdf" }
    ],
    patterns: ["hostel fee", "hostel fees", "hostel fee structure", "mess fee", "mess charges per month", "how much is hostel and mess fee", "hostel maintenance charge", "hostel caution money", "hostel ka fee kitna hai", "mess charge kitna lagta hai", "how to pay hostel fee", "hostel rent"],
    responses: ["BCE Patna Hostel & Mess Fees (as per official 2026 notices):\n• Hostel Admission Charge: ₹500 (one-time)\n• Caution Money: ₹1,500 (one-time)\n• Maintenance Charge: ₹1,200/month (₹14,400/year)\n• Mess Charge: ₹3,700–₹4,200/month (varies by hostel, typically paid 3 months at a time)\nPay online via the 'Hostel Fee Payment' link on bcebakhtiyarpur.ac.in (UPI / Card / Net Banking)."]
  },
  {
    tag: "scholarships", title: "Scholarships & BSCC Loan", next: ["fees", "professor_incharge_cells"],
    links: [
      { label: "Check Scholarship Notices", url: "https://bcebakhtiyarpur.ac.in/?s=scholarship", type: "search" },
      { label: "Administration Directory", url: "https://bcebakhtiyarpur.ac.in/about-us/administration/", type: "web" }
    ],
    patterns: ["scholarships available", "post matric scholarship pms", "bihar student credit card", "bscc loan facility", "financial aid", "tuition fee waiver tfw", "scholarship milta hai kya", "4 lakh education loan"],
    responses: ["BCE Patna students can apply for:\n• Bihar Student Credit Card (BSCC) scheme (education loan up to ₹4 lakh) — Cell In-charge: Dr. Ravi Shankar\n• Bihar Post-Matric Scholarship (PMS) for eligible categories\n• Tuition Fee Waiver (TFW) seats"]
  },
  {
    tag: "professor_incharge_cells", title: "Professor In-Charge & Cells", next: ["women_grievance_icc", "contact_info"],
    links: [{ label: "Official Administration Directory", url: "https://bcebakhtiyarpur.ac.in/about-us/administration/", type: "web" }],
    patterns: ["professor incharge list", "college cells and incharge", "administration incharge table", "key officers of bce", "college administration list"],
    responses: ["Official Professor In-Charge Directory (bcebakhtiyarpur.ac.in):\n• Principal: Dr. Amrita Sinha\n• Academic / Admission / Anti-Ragging: Prof. Shahabuddin Baqar\n• Examination / Students Grievance / Boys Hostel Warden: Prof. Navin Kumar Mishra\n• Training & Placement (TPO): Dr. Rajeev Ranjan\n• Students Credit Card (BSCC): Dr. Ravi Shankar\n• Students Biometric: Dr. Suraj Singh Sisodiya\n• Women Helpline: Prof. Pragya Chaudhary\n(Tip: Type any professor's name to see their individual profile!)"]
  },
  {
    tag: "cse_department", title: "CSE Department & Faculty", next: ["cse_iot_department", "applied_science_department"],
    links: [{ label: "CSE Faculty Page", url: "https://bcebakhtiyarpur.ac.in/department/computer-engineering/faculty-of-computer-engineering/", type: "web" }],
    patterns: ["computer science faculty", "about cse department", "cse professors in bce patna", "cse faculty list", "ai and machine learning in cse"],
    responses: ["Department of Computer Engineering (CSE):\n• HOD: Prof. Bhawana Singh\n• Faculty: Prof. Shahab Saquib, Prof. Ajeet Kumar, Dr. Rajeev Ranjan, Prof. Alok Kumar, Prof. Afaque Alam, Prof. Reena Kumari, Dr. Shashi Raj, Prof. Pragya Chaudhary, and Prof. Shivangi Shekhar.\n(Type any professor's name for their individual details!)"]
  },
  {
    tag: "cse_iot_department", title: "CSE (IoT) Department", next: ["cse_department", "seat_intake"],
    links: [{ label: "Official Syllabus Page", url: "https://bcebakhtiyarpur.ac.in/academics/syllabus/", type: "web" }],
    patterns: ["about cse iot branch", "internet of things department bce", "cse iot syllabus and labs", "is iot good in bce patna", "computer science iot faculty"],
    responses: ["BCE Patna offers B.Tech in Computer Science & Engineering (Internet of Things - IoT) (60 regular seats + 3 TFW + 6 LE) with dedicated Labs, Mentor List, Course Files, Question Bank, and Attendance/Result tracking on bcebakhtiyarpur.ac.in."]
  },
  {
    tag: "eee_department", title: "EEE Department & Faculty", next: ["mech_department", "professor_incharge_cells"],
    links: [{ label: "Search EEE Updates on Site", url: "https://bcebakhtiyarpur.ac.in/?s=electrical", type: "search" }],
    patterns: ["electrical and electronics faculty", "about eee department", "electrical engineering professors in bce", "eee faculty list"],
    responses: ["Department of Electrical & Electronics Engineering (EEE):\n• HOD: Prof. (Dr.) Shahiruddin\n• Principal & Registrar from EEE: Dr. Amrita Sinha (Principal) and Prof. Shahab Uddin Baqar (Registrar)\n• Faculty: Prof. Nishi Bala, Prof. Kumari Nirmala, Dr. Om Prakash Gujela, Prof. Harideo Ram, Dr. Nimish Kumar, Prof. Reena Kumari, and Dr. Sujit Kumar.\n(Type any professor's name for their individual profile!)"]
  },
  {
    tag: "mech_department", title: "Mechanical Dept & Faculty", next: ["civil_department", "eee_department"],
    links: [{ label: "Dr. Anil Singh Yadav Profile", url: "https://bcebakhtiyarpur.ac.in/faculty/dr-anil-singh-yadav/", type: "web" }],
    patterns: ["mechanical engineering faculty", "about mechanical department", "mechanical professors", "mechanical faculty list"],
    responses: ["Department of Mechanical Engineering:\n• HOD: Dr. Anil Singh Yadav (Associate Professor, PhD MANIT Bhopal, Stanford Top 2% Scientist)\n• Faculty: Dr. Manish Kumar, Prof. Rajeev Ranjan, Prof. Aman Kumar, Prof. Surendra Singh, Dr. Vikash Kumar, Mr. Sudarshan, Dr. Nitesh Kumar, and Dr. Niraj Kumar."]
  },
  {
    tag: "civil_department", title: "Civil Dept & Faculty", next: ["mech_department", "fire_tech_department"],
    links: [{ label: "Search Civil Dept Updates", url: "https://bcebakhtiyarpur.ac.in/?s=civil", type: "search" }],
    patterns: ["civil engineering faculty", "about civil department", "civil professors in bce", "civil faculty list"],
    responses: ["Department of Civil Engineering:\n• HOD: Dr. Rajesh Kumar (PhD IIT Delhi, Structural & Earthquake Engineering)\n• Faculty: Prof. Hariom Shankar, Prof. Ankita Singh, Prof. Raman Kumar, Dr. Astha Kumari, Prof. Kritika Kaushal, and Prof. Vandana Anand.\n(Dr. Bijendra Kumar is on deputation at BEU Patna and Dr. Subha Sinha at Tara Mandal, Patna.)"]
  },
  {
    tag: "fire_tech_department", title: "Fire Technology & Safety", next: ["courses_branches", "seat_intake"],
    links: [{ label: "About Fire Technology Page", url: "https://bcebakhtiyarpur.ac.in/department/fire-technology-safety/about-fire-technology-safety/", type: "web" }],
    patterns: ["about fire technology and safety", "fire tech department bce patna", "fire safety engineering branch", "fire technology labs and question bank", "fire tech kya hai"],
    responses: ["BCE Patna offers a specialized B.Tech in Fire Technology & Safety Engineering (30 regular seats + 2 TFW + 3 LE), featuring dedicated Labs & Infrastructure, Mentor List, Course Files, Question Bank, and safety training."]
  },
  {
    tag: "applied_science_department", title: "1st-Year Applied Science Dept", next: ["cse_department", "rules_attendance_biometric"],
    links: [{ label: "About Applied Science Dept", url: "https://bcebakhtiyarpur.ac.in/department/basic-science/about-basic-science/", type: "web" }],
    patterns: ["applied science and humanities department", "first year faculty bce patna", "who teaches maths physics chemistry english", "1st semester department", "basic science faculty list"],
    responses: ["Department of Applied Science & Humanities (1st-Year Core Subjects):\n• HOD (Maths): Dr. Kumar Amitabh\n• Maths: Dr. Alka Kumari, Dr. Priti Kumari, Dr. Anupama\n• Chemistry: Prof. Harendra Kumar (Dr. Anant Kumar on deputation at DSTTE)\n• Physics: Dr. Shiv Shanker Sahay (deputation at BCST)\n• English: Dr. Suraj Singh Sisodiya | Geology: Dr. Ravi Shankar."]
  },
  {
    tag: "library", title: "Central Library Timings", next: ["campus_facilities", "student_portal_login"],
    links: [{ label: "Official Central Library Page", url: "https://bcebakhtiyarpur.ac.in/facilities-and-services/central-library/", type: "web" }],
    patterns: ["library timings", "when is the central library open", "library hours", "does bce have a library", "books and digital library", "library seating capacity", "library kab khulta hai", "gate bpsc books in library"],
    responses: ["The BCE Patna Central Library seats 150 students, includes 20 PCs for digital learning, and stocks engineering textbooks, journals, and GATE/BPSC preparation material.\n• Mon–Fri: 10:00 AM – 5:00 PM\n• Saturday: 10:00 AM – 10:00 PM\n• Sunday: 6:00 AM – 2:00 PM"]
  },
  {
    tag: "hostel_mess", title: "Hostels & Mess Facilities", next: ["hostel_fee", "hostel_allotment_leave"],
    links: [
      { label: "Official Hostels Page", url: "https://bcebakhtiyarpur.ac.in/facilities-and-services/hostels/", type: "web" },
      { label: "Hostel Undertaking & Rules", url: "https://bcebakhtiyarpur.ac.in/wp-content/uploads/2025/07/Adobe-Scan-26-Jul-2025-1.pdf", type: "pdf" }
    ],
    patterns: ["is hostel available", "how many hostels are in bce patna", "boys and girls hostel", "hostel facilities", "mess food quality", "hostel milta hai kya", "girls hostel facility", "hostel rooms sharing"],
    responses: ["BCE Patna provides separate on-campus boys' and girls' hostels (including Boys Hostel-1 and Girls Hostel-2) with spacious rooms, hygienic mess food, wardens, indoor games, Wi-Fi, and 24/7 security."]
  },
  {
    tag: "hostel_allotment_leave", title: "Hostel Allotment & Leave", next: ["hostel_fee", "professor_incharge_cells"],
    links: [
      { label: "Search Hostel Notices", url: "https://bcebakhtiyarpur.ac.in/?s=hostel", type: "search" },
      { label: "Hostel Undertaking & Rules", url: "https://bcebakhtiyarpur.ac.in/wp-content/uploads/2025/07/Adobe-Scan-26-Jul-2025-1.pdf", type: "pdf" }
    ],
    patterns: ["how to apply for hostel", "hostel allotment notice", "boys hostel 1 allotment", "girls hostel application form", "hostel leave notice", "hostel rules and warden", "hostel chutti notice"],
    responses: ["Hostel admission requires submitting the Hostel Application Form and undertaking (PDF linked below). Boys Hostel Warden: Prof. Navin Kumar Mishra. Latest allotment lists and leave notices (05 Nov 2026) are published on bcebakhtiyarpur.ac.in."]
  },
  {
    tag: "canteen", title: "Campus Canteen", next: ["hostel_mess", "campus_facilities"],
    links: [{ label: "Search Canteen Notices", url: "https://bcebakhtiyarpur.ac.in/?s=canteen", type: "search" }],
    patterns: ["is there a canteen", "college cafeteria", "canteen food quality", "where to get snacks on campus", "canteen hai kya"],
    responses: ["Yes! BCE Patna has a spacious, well-furnished campus canteen supervised regularly by the college food committee."]
  },
  {
    tag: "sports_kaushal_manthan", title: "Sports & Kaushal Manthan", next: ["clubs_societies", "campus_events"],
    links: [{ label: "Search Sports & Kaushal Manthan", url: "https://bcebakhtiyarpur.ac.in/?s=sports", type: "search" }],
    patterns: ["sports facilities in bce", "what is kaushal manthan", "badminton volleyball kabaddi ground", "indoor games in hostel", "annual sports fest", "khel kud sports kya hai", "table tennis chess carrom yoga"],
    responses: ["BCE Patna has outdoor courts for badminton, volleyball, and Kabaddi, plus indoor sports in hostels (Table Tennis, Carrom, Chess, Yoga). Its annual sports fest 'Kaushal Manthan' feeds winners into state-level DSTTE tournaments."]
  },
  {
    tag: "clubs_societies", title: "Student Clubs & Societies", next: ["campus_events", "skill_startup_nptel"],
    links: [{ label: "Official Website", url: "https://bcebakhtiyarpur.ac.in/", type: "web" }],
    patterns: ["student clubs and societies", "is there a coding club", "photography and design club", "literature poetry drama club", "social service club", "extracurricular activities", "coding culture in bce"],
    responses: ["BCE Patna has 12+ active clubs & societies, including Coding Club, Photography Club, Visual Design Club (Canva, Adobe, Photoshop), Debating Society, Dramatics & Literature Club, Sports Club, Innovation Club, and Social Service Club."]
  },
  {
    tag: "campus_events", title: "Fests, Hackathons & Events", next: ["clubs_societies", "sports_kaushal_manthan"],
    links: [{ label: "Latest Event Notices", url: "https://bcebakhtiyarpur.ac.in/category/notices/", type: "web" }],
    patterns: ["college fest and techfest", "what is inception freshers party", "what is yantriksha techfest", "robotics event bce", "yoga day and independence day", "problem solving camp", "cultural events in bce"],
    responses: ["BCE Patna hosts annual Freshers' Party ('Inception'), Techfest ('Yantriksha'), Robotics events, Smart India Hackathon, 3-Day Problem Solving Camps (Oct 2026), Yoga Day, and Independence Day celebrations."]
  },
  {
    tag: "skill_startup_nptel", title: "Start-up Cell, NPTEL & Skill Mission", next: ["placements", "nats_internships"],
    links: [{ label: "Search Startup & NPTEL", url: "https://bcebakhtiyarpur.ac.in/?s=startup", type: "search" }],
    patterns: ["what is startup cell", "nptel courses in bce", "skill development mission rpl", "smart india hackathon", "alumni association portal", "government skill certification"],
    responses: ["BCE Patna promotes skill-building via NPTEL courses, the Start-up Cell, Alumni Association Portal, Smart India Hackathon, and the Bihar Skill Development Mission (RPL), where training and assessment fees are covered by the Government."]
  },
  {
    tag: "placements", title: "Training & Placements", next: ["nats_internships", "professor_incharge_cells"],
    links: [
      { label: "Placement Brochure 2025-26", url: "https://bcebakhtiyarpur.ac.in/bce-bakhtiyarpur-placement-brochure-2025-26/", type: "web" },
      { label: "Placement Cell Updates", url: "https://bcebakhtiyarpur.ac.in/category/placement/", type: "web" }
    ],
    patterns: ["how are placements", "training and placement cell", "which companies visit bce patna", "top recruiters", "placement brochure 2025 26", "average and highest package", "placement kaisa hai", "job lagta hai kya"],
    responses: ["BCE Patna has an active Training & Placement Cell (Placement Brochure 2025–26 published Jan 2026) led by Dr. Rajeev Ranjan (tpobcebkp@gmail.com). Placement partners and recruiters include TCS, IOCL (Indian Oil), DRDO, and Prism Cement."]
  },
  {
    tag: "nats_internships", title: "NATS & Internships", next: ["placements", "latest_notices"],
    links: [
      { label: "Search NATS Notices", url: "https://bcebakhtiyarpur.ac.in/?s=NATS", type: "search" },
      { label: "Placement Cell Updates", url: "https://bcebakhtiyarpur.ac.in/category/placement/", type: "web" }
    ],
    patterns: ["what is nats in bce patna", "nats walk in interview", "nats final result 2026", "internship opportunities", "ntpc irctc iocl internship", "apprenticeship training"],
    responses: ["BCE Patna conducts National Apprenticeship Training Scheme (NATS) selections (latest notice: Final Result of NATS dated 22 Nov 2026). Students also pursue industrial internships with organizations like NTPC, IRCTC, IOCL, and DRDO."]
  },
  {
    tag: "campus_facilities", title: "Campus Infrastructure & Labs", next: ["library", "hostel_mess"],
    links: [
      { label: "Central Library", url: "https://bcebakhtiyarpur.ac.in/facilities-and-services/central-library/", type: "web" },
      { label: "Hostels & Mess", url: "https://bcebakhtiyarpur.ac.in/facilities-and-services/hostels/", type: "web" }
    ],
    patterns: ["campus facilities", "does college have wifi", "computer center and labs", "medical facility and doctor", "gymnasium and guest house", "bank and atm on campus", "wifi milta hai kya", "ac smartboard classrooms"],
    responses: ["BCE Patna offers smart classrooms, department labs, Computer Center, Central Library, campus Wi-Fi, Sports grounds, Gymnasium, Medical Facility, Guest House, Canteen, and Bank services."]
  },
  {
    tag: "rules_attendance_biometric", title: "Attendance, Biometric & Rules", next: ["professor_incharge_cells", "exams_notices"],
    links: [
      { label: "Academic Calendar", url: "https://bcebakhtiyarpur.ac.in/academics/academic-calendar/", type: "web" },
      { label: "Administration Directory", url: "https://bcebakhtiyarpur.ac.in/about-us/administration/", type: "web" }
    ],
    patterns: ["biometric attendance rule", "college disciplinary rules", "unfair means exam rule", "minimum attendance required", "academic regulations and holidays"],
    responses: ["BCE Patna follows Bihar Government College Disciplinary Rules and university Unfair Means regulations. Biometric attendance is managed by Dr. Suraj Singh Sisodiya. Academic Calendar and Regulations are published under Academics on bcebakhtiyarpur.ac.in."]
  },
  {
    tag: "anti_ragging", title: "Anti-Ragging Policy", next: ["women_grievance_icc", "hostel_mess"],
    links: [{ label: "Administration & Anti-Ragging Cell", url: "https://bcebakhtiyarpur.ac.in/about-us/administration/", type: "web" }],
    patterns: ["is there ragging in bce", "anti ragging cell", "student safety", "is campus safe for freshers", "ragging hota hai kya"],
    responses: ["BCE Patna maintains a strict zero-tolerance Anti-Ragging policy with a dedicated Anti-Ragging Cell headed by Prof. Shahabuddin Baqar."]
  },
  {
    tag: "women_grievance_icc", title: "Women Helpline, Grievance & ICC", next: ["anti_ragging", "professor_incharge_cells"],
    links: [{ label: "Administration & Helplines", url: "https://bcebakhtiyarpur.ac.in/about-us/administration/", type: "web" }],
    patterns: ["women helpline bce patna", "student grievance redressal", "internal complaint committee icc", "how to file a complaint", "feedback system", "girls safety helpline"],
    responses: ["BCE Patna student support cells:\n• Women Helpline In-charge: Prof. Pragya Chaudhary\n• Student Grievance Redressal & Feedback: Prof. Navin Kumar Mishra\n• Internal Complaint Committee (ICC) listed under Academics on bcebakhtiyarpur.ac.in."]
  },
  {
    tag: "exams_notices", title: "Exams, Timetable & Syllabus", next: ["latest_notices", "student_portal_login"],
    links: [
      { label: "Official Notices & Timetables", url: "https://bcebakhtiyarpur.ac.in/category/notices/", type: "web" },
      { label: "Official B.Tech Syllabus", url: "https://bcebakhtiyarpur.ac.in/academics/syllabus/", type: "web" },
      { label: "Academic Calendar", url: "https://bcebakhtiyarpur.ac.in/academics/academic-calendar/", type: "web" }
    ],
    patterns: ["where to check exam timetable", "semester exam dates", "practical exam schedule", "supplementary exam result", "class routine and syllabus", "exam kab hoga", "previous year question bank"],
    responses: ["Semester registration notices, revised timetables, practical schedules (4th & 6th sem Nov 2026), and supplementary results are posted under Notices on bcebakhtiyarpur.ac.in. Open the official Syllabus or Calendar below."]
  },
  {
    tag: "student_portal_login", title: "Student Login & Web-Email", next: ["exams_notices", "contact_info"],
    links: [{ label: "Open BCE Official Portal", url: "https://bcebakhtiyarpur.ac.in/", type: "web" }],
    patterns: ["student login portal", "faculty login bce", "college web email", "where to find mentor list", "course file and attendance portal", "online portal login"],
    responses: ["bcebakhtiyarpur.ac.in provides Student Login, Faculty Login, Admin Login, and Web-Email, plus department-wise Mentor Lists, Course Files, Question Banks, and Attendance."]
  },
  {
    tag: "contact_info", title: "Official Contact Details", next: ["location", "professor_incharge_cells"],
    links: [
      { label: "BCE Patna Website", url: "https://bcebakhtiyarpur.ac.in/", type: "web" },
      { label: "BEU University Portal", url: "https://beu-bih.ac.in/", type: "web" },
      { label: "BCECEB Counselling", url: "https://bceceboard.bihar.gov.in/", type: "web" }
    ],
    patterns: ["contact details", "college email id", "official website", "how to contact bce patna", "college phone number", "website link", "beu portal link"],
    responses: ["Official Website: https://bcebakhtiyarpur.ac.in/\nGeneral Email: bcebakhtiyarpur@gmail.com\nPrincipal Email: principal@bcebakhtiyarpur.ac.in\nAddress: Champapur, Dedaur, Bakhtiyarpur, Patna - 803212."]
  },
  {
    tag: "campus_tour", title: "Campus & Hostel Tour Videos", next: ["campus_facilities", "hostel_mess"],
    links: [{ label: "Watch Official Campus Tour", url: "https://bcebakhtiyarpur.ac.in/video/bce-patna-campus-tour-official-video/", type: "web" }],
    patterns: ["is there a campus tour video", "show me bce patna campus", "how does campus look", "hostel tour video", "campus kaisa dikhta hai"],
    responses: ["Watch the official BCE Patna Campus Tour video directly on bcebakhtiyarpur.ac.in using the button below."]
  },
  {
    tag: "about_bot", title: "How This AI Works", next: ["latest_notices", "about_college"],
    patterns: ["who made you", "how do you work", "are you using chatgpt", "what technology do you use", "about this project", "which ml algorithm do you use", "tum kaise kaam karte ho"],
    responses: ["I am a 3-Layer Hybrid On-Device AI built with zero external AI APIs:\n1. Structured Faculty & Entity Lookup (27 verified BCE profiles)\n2. On-Device PDF / Document RAG Reader (passage search inside uploaded PDFs & notes)\n3. Ensemble ML Classifier (Levenshtein spell correction + Stopword-weighted TF-IDF + Softmax Logistic Regression + Cosine Similarity)"]
  },
  {
    tag: "thanks", title: "Thanks", next: ["latest_notices", "courses_branches"],
    patterns: ["thank you", "thanks", "thanks a lot", "that was helpful", "great info", "thx", "shukriya", "dhanyawad"],
    responses: ["You're welcome! Let me know if you need anything else about BCE Patna.", "Happy to help! All the best with your studies at BCE Patna."]
  },
  {
    tag: "goodbye", title: "Goodbye", next: ["greeting"],
    patterns: ["bye", "goodbye", "see you later", "exit", "quit", "catch you later", "alvida"],
    responses: ["Goodbye! Have a great day ahead.", "See you later! Feel free to come back anytime for BCE Patna info."]
  }
];

// =========================================================
// 3. STOPWORDS & SMS SHORTHAND DICTIONARY
// =========================================================
const STOPWORDS = new Set([
  "what", "is", "are", "was", "were", "the", "a", "an", "of", "to", "in", "on", "for", "at", "by", "with", "from",
  "about", "tell", "me", "give", "detail", "details", "info", "information", "please", "can", "you", "i", "want",
  "know", "does", "do", "have", "has", "their", "there", "and", "or", "this", "that", "my", "your", "full", "some",
  "ki", "ka", "ke", "ko", "se", "hai", "h", "hain", "kya", "batao", "bataiye", "bare", "mein", "mujhe", "chahiye",
  "prof", "dr", "mr", "mrs"
]);

const SHORTHAND = {
  clg: "college", cllg: "college", dept: "department", lib: "library",
  tym: "timings", tyming: "timings", engg: "engineering",
  sem: "semester", adm: "admission", schol: "scholarship",
  plcmnt: "placements", doc: "documents", docs: "documents",
  tt: "timetable", mech: "mechanical", cs: "cse"
};