// =========================================================
// live.js: live data from the college website (no server of our own).
// Notices / pages / search come from the site's WordPress REST feed.
// PDFs are fetched directly; if the website blocks that, an opt-in public relay can be used.
// =========================================================

const LIVE_CACHE_KEY = "bce_v5_live";
const LIVE_RELAY_KEY = "bce_v5_relay";
const LIVE_TIMEOUT_MS = 9000;
const LIVE_MAX_PDF = 15 * 1024 * 1024;
const DEFAULT_RELAYS = [
  (u) => "https://corsproxy.io/?url=" + encodeURIComponent(u),
  (u) => "https://api.allorigins.win/raw?url=" + encodeURIComponent(u),
  (u) => "https://api.codetabs.com/v1/proxy?quest=" + encodeURIComponent(u)
];

function liveBase() {
  return (typeof window !== "undefined" && window.BCE_LIVE_BASE) || OFFICIAL_SITE;
}
function liveRelays() {
  return (typeof window !== "undefined" && window.BCE_RELAYS) || DEFAULT_RELAYS;
}
function relayEnabled() {
  return loadStorage(LIVE_RELAY_KEY, false) === true;
}
function liveHost() {
  try {
    return new URL(liveBase()).host;
  } catch (e) {
    return "the college website";
  }
}

async function liveFetch(url, signalMs = LIVE_TIMEOUT_MS) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), signalMs);
  try {
    const res = await fetch(url, { mode: "cors", signal: ctl.signal });
    if (!res.ok) throw Object.assign(new Error("http " + res.status), { status: res.status });
    return res;
  } finally {
    clearTimeout(timer);
  }
}
async function liveGetJson(path) {
  return (await liveFetch(liveBase() + path)).json();
}

// HTML -> plain text without ever inserting it into the page
function htmlToText(html) {
  const doc = new DOMParser().parseFromString(String(html || ""), "text/html");
  doc.querySelectorAll("script,style").forEach((n) => n.remove());
  return (doc.body.textContent || "").replace(/\s+/g, " ").trim();
}
function extractPdfLinks(html) {
  const doc = new DOMParser().parseFromString(String(html || ""), "text/html");
  const out = [];
  doc.querySelectorAll("a[href]").forEach((a) => {
    try {
      const url = new URL(a.getAttribute("href"), liveBase()).href;
      if (/\.pdf(\?|#|$)/i.test(url) && isSafeUrl(url) && !out.some((p) => p.url === url)) {
        out.push({ url, label: (a.textContent || "").replace(/\s+/g, " ").trim().slice(0, 80) });
      }
    } catch (e) {}
  });
  return out.slice(0, 4);
}

function parseWpItem(p) {
  const html = (p.content && p.content.rendered) || (p.excerpt && p.excerpt.rendered) || "";
  return {
    id: p.id,
    type: p.type === "page" ? "page" : "post",
    title: htmlToText(p.title && p.title.rendered) || "(untitled)",
    date: String(p.date || "").slice(0, 10),
    url: isSafeUrl(p.link) ? p.link : liveBase(),
    pdfs: extractPdfLinks(html),
    text: htmlToText(html)
  };
}
const compactItem = (i) => ({ id: i.id, type: i.type, title: i.title.slice(0, 160), date: i.date, url: i.url, pdfs: i.pdfs });

function readLiveCache() {
  const c = loadStorage(LIVE_CACHE_KEY, null);
  return c && Array.isArray(c.items) && c.fetchedAt ? c : null;
}

async function liveLatestNotices(limit = 8) {
  let catId = null;
  try {
    const cats = await liveGetJson("/wp-json/wp/v2/categories?slug=notices&_fields=id");
    catId = cats[0] && cats[0].id;
  } catch (e) {
    if (!e.status) throw e; // blocked / offline / timeout: stop here. An HTTP error just means "no such category"
  }
  const posts = await liveGetJson(
    `/wp-json/wp/v2/posts?per_page=${limit}&orderby=date&order=desc&_fields=id,date,link,title,content,type` + (catId ? `&categories=${catId}` : "")
  );
  let items = posts.map(parseWpItem).map(compactItem);
  try {
    // PDFs that were uploaded without a post
    const media = await liveGetJson("/wp-json/wp/v2/media?mime_type=application/pdf&per_page=8&orderby=date&order=desc&_fields=id,date,source_url,title");
    for (const m of media) {
      if (!isSafeUrl(m.source_url) || items.some((i) => i.pdfs.some((p) => p.url === m.source_url))) continue;
      const title = htmlToText(m.title && m.title.rendered) || "PDF notice";
      items.push({ id: m.id, type: "media", title, date: String(m.date || "").slice(0, 10), url: m.source_url, pdfs: [{ url: m.source_url, label: title }] });
    }
  } catch (e) {}
  items = items.sort((a, b) => (a.date < b.date ? 1 : -1)).slice(0, limit);
  const result = { items, fetchedAt: Date.now() };
  saveStorage(LIVE_CACHE_KEY, result);
  return { ...result, fromCache: false };
}

// online: live (falls back to the saved copy); offline: saved copy
async function liveNotices(limit = 8) {
  if (navigator.onLine) {
    try {
      return await liveLatestNotices(limit);
    } catch (err) {
      const c = readLiveCache();
      if (c) return { ...c, fromCache: true, error: err };
      throw err;
    }
  }
  const c = readLiveCache();
  if (c) return { ...c, fromCache: true, offline: true };
  throw Object.assign(new Error("offline"), { offline: true });
}

async function liveSearch(q) {
  const enc = encodeURIComponent(q);
  try {
    const r = await liveGetJson(`/wp-json/wp/v2/search?search=${enc}&per_page=6&_fields=id,title,url,subtype`);
    return r.filter((x) => isSafeUrl(x.url)).map((x) => ({ id: x.id, type: x.subtype === "page" ? "page" : "post", title: htmlToText(x.title), url: x.url }));
  } catch (e) {
    if (!e.status) throw e;
    const r = await liveGetJson(`/wp-json/wp/v2/posts?search=${enc}&per_page=6&_fields=id,title,link`);
    return r.map((x) => ({ id: x.id, type: "post", title: htmlToText(x.title && x.title.rendered), url: x.link }));
  }
}

// ---- PDFs: direct first, relay only if the user switched it on -------------------------------
async function fetchPdfFrom(url) {
  const res = await liveFetch(url, 20000);
  const buf = await res.arrayBuffer();
  if (buf.byteLength > LIVE_MAX_PDF) throw new Error("too big");
  if (String.fromCharCode(...new Uint8Array(buf.slice(0, 5))) !== "%PDF-") throw new Error("not a PDF");
  return buf;
}

// mode: "auto" | "direct" | "relay"
async function liveFetchPdf(url, mode = "auto") {
  const secure = /^https:/i.test(url) || /^http:\/\/localhost[:/]/.test(url);
  if (!isSafeUrl(url) || !secure) throw new Error("Only https links are supported.");
  let directError = null;
  if (mode !== "relay") {
    try {
      return { buf: await fetchPdfFrom(url), via: "direct" };
    } catch (e) {
      directError = e;
    }
  }
  if (mode === "direct" || (mode === "auto" && !relayEnabled())) {
    throw Object.assign(new Error("blocked"), { blocked: true, relayOff: mode === "auto", cause: directError });
  }
  for (const make of liveRelays()) {
    try {
      return { buf: await fetchPdfFrom(make(url)), via: "relay" };
    } catch (e) {}
  }
  throw Object.assign(new Error("blocked"), { blocked: true, relayTried: true, cause: directError });
}

function liveReason(err) {
  if (!err) return "unknown problem";
  if (err.offline || (typeof navigator !== "undefined" && !navigator.onLine)) return "you are offline";
  if (err.name === "AbortError") return "the website took too long to answer";
  if (err.status === 404 || err.status === 403) return "the website's data feed is switched off";
  if (err.status) return `the website answered with an error (${err.status})`;
  return "the website blocked the request or did not answer";
}

function clock(ms) {
  return new Date(ms).toLocaleString([], { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
}
function shortDate(iso) {
  return iso ? fmtDate(iso) : "";
}

// ---- turning results into chat answers --------------------------------------------------------
function noticesAnswer(r, staticRes) {
  const lines = [`🆕 Latest notices from ${liveHost()}`];
  r.items.forEach((i) => lines.push(`• ${shortDate(i.date)}: ${i.title}${i.pdfs.length ? " (PDF)" : ""}`));
  lines.push(
    "",
    r.fromCache
      ? `ℹ️ Saved copy from ${clock(r.fetchedAt)}${r.offline ? " (you are offline)" : ": " + liveReason(r.error) + ", so this may be out of date"}.`
      : `ℹ️ Fetched live at ${clock(r.fetchedAt)}.`
  );
  const withPdf = r.items.filter((i) => i.pdfs.length).slice(0, 4);
  return {
    reply: lines.join("\n"),
    intent: "live_notices",
    confidence: "98.0",
    sourceType: "live",
    sourceLabel: r.fromCache ? "Saved copy of the website" : "Live from " + liveHost(),
    links: r.items.slice(0, 3).map((i) => ({ label: i.title.slice(0, 40), url: i.pdfs[0] ? i.pdfs[0].url : i.url, type: i.pdfs.length ? "pdf" : "web" })),
    suggestions: withPdf.map((i) => ({ label: "Explain: " + i.title.slice(0, 28), query: "__pdf__:" + i.pdfs[0].url }))
  };
}

function searchAnswer(items, q) {
  if (!items.length) {
    return { reply: `I found nothing on ${liveHost()} for "${q}". Try other words.`, intent: "live_page", confidence: "60.0", sourceType: "live", sourceLabel: "Live from " + liveHost(), links: [], suggestions: [] };
  }
  return {
    reply: `🔎 Results on ${liveHost()} for "${q}":\n` + items.map((i) => `• ${i.title}`).join("\n") + "\n\nTap a result to read it here.",
    intent: "live_page",
    confidence: "90.0",
    sourceType: "live",
    sourceLabel: "Live from " + liveHost(),
    links: items.slice(0, 2).map((i) => ({ label: i.title.slice(0, 40), url: i.url, type: "web" })),
    suggestions: items.slice(0, 4).map((i) => ({ label: "Read: " + i.title.slice(0, 26), query: `__page__:${i.type}:${i.id}` }))
  };
}

function liveFailure(err, staticRes) {
  const why = liveReason(err);
  if (staticRes) {
    return { ...staticRes, reply: staticRes.reply + `\n\n⚠️ I couldn't reach the live website (${why}), so this is my saved information.` };
  }
  return {
    reply: `I couldn't get that from ${liveHost()} (${why}). You can open the website directly:`,
    intent: "error",
    confidence: "0.0",
    links: [{ label: "Open official website", url: liveBase(), type: "web" }],
    suggestions: []
  };
}

// What the user typed -> a live request, or null (normal answer)
function detectLiveRequest(text) {
  const t = text.trim();
  const url = t.match(/https?:\/\/[^\s]+?\.pdf(?:\?[^\s]*)?/i);
  if (url) {
    try {
      if (new URL(url[0]).host === liveHost()) return { kind: "pdf", url: url[0] };
    } catch (e) {}
  }
  if (/\b(live|fetch|refresh|check|latest|new|recent|naya|nayi|current|today)\b[^.?!]{0,25}\b(notices?|circulars?|announcements?)\b/i.test(t) || /\b(notices?|circulars?)\b[^.?!]{0,15}\b(latest|new|recent|aaj|today|live)\b/i.test(t)) {
    return { kind: "notices" };
  }
  if (/\b(search|find|look\s*up|dhundo|khojo)\b/i.test(t) && /\b(website|site|online|live)\b/i.test(t)) {
    const q = t.replace(/\b(please|search|find|look\s*up|dhundo|khojo|on|in|the|college|bce|website|site|online|live|for|from|fetch|get|about)\b/gi, " ").replace(/\s+/g, " ").trim();
    if (q.length >= 2) return { kind: "search", q };
  }
  return null;
}

async function handleLive(req, text, staticRes) {
  let res;
  try {
    if (req.kind === "pdf") {
      removeTypingBubble();
      replyPending = false;
      explainPdfUrl(req.url);
      return;
    }
    res = req.kind === "search" ? searchAnswer(await liveSearch(req.q), req.q) : noticesAnswer(await liveNotices(8), staticRes);
  } catch (err) {
    res = liveFailure(err, staticRes);
  }
  removeTypingBubble();
  replyPending = false;
  finishReply(text, res);
}

// ---- explain a PDF from the website ------------------------------------------------------------
async function explainPdfUrl(url) {
  const name = decodeURIComponent(url.split("?")[0].split("/").pop() || "notice.pdf");
  const saved = uploadedDocs.find((d) => d.sourceUrl === url && d.summary);
  if (saved) {
    postDocSummary(saved, null); // already read: instant, works offline
    return;
  }
  const fallback = {
    links: [{ label: "Open the PDF", url, type: "pdf" }],
    suggestions: [{ label: "Upload it instead", query: "__open_docs__" }],
    intent: "error",
    confidence: "0.0"
  };
  if (!navigator.onLine) {
    postBotMessage({ ...fallback, text: "You are offline and I haven't saved this PDF yet. Connect to the internet and tap it again." });
    return;
  }
  showToast("Fetching the PDF…");
  try {
    const { buf, via } = await liveFetchPdf(url);
    await indexPdfBuffer(buf, name, { sourceUrl: url, via }, { style: {}, textContent: "" });
    if (via === "relay") {
      postBotMessage({ ...fallback, intent: "live_page", confidence: "60.0", suggestions: [], text: "ℹ️ This PDF came through a public relay service, not directly from the college. Please check the details against the original (link below)." });
    }
  } catch (err) {
    let msg;
    if (err.blocked) {
      msg =
        "I couldn't download that PDF: the college website doesn't let other pages read its files." +
        (err.relayTried
          ? " The public relays didn't work either."
          : " You can switch on the public relay (Documents tab → Live data), or open the PDF, save it, and upload it here.");
    } else msg = err.message || "Could not read that PDF.";
    postBotMessage({ ...fallback, text: msg });
  }
}

async function readSitePage(type, id) {
  showToast("Opening the page…");
  try {
    const item = parseWpItem(await liveGetJson(`/wp-json/wp/v2/${type === "page" ? "pages" : "posts"}/${encodeURIComponent(id)}?_fields=id,date,link,title,content,type`));
    postBotMessage({
      text: `📄 ${item.title}\n\n${item.text.slice(0, 1500)}${item.text.length > 1500 ? "…" : ""}\n\nℹ️ Fetched live from ${liveHost()} at ${clock(Date.now())}.`,
      intent: "live_page",
      sourceType: "live",
      sourceLabel: "Live from " + liveHost(),
      links: [{ label: "Open page", url: item.url, type: "web" }],
      suggestions: item.pdfs.slice(0, 4).map((p) => ({ label: "Explain: " + (p.label || "PDF").slice(0, 28), query: "__pdf__:" + p.url }))
    });
  } catch (err) {
    postBotMessage({ text: `I couldn't open that page (${liveReason(err)}).`, intent: "error", confidence: "0.0", links: [{ label: "Open official website", url: liveBase(), type: "web" }], suggestions: [] });
  }
}

// ---- drawer controls ----------------------------------------------------------------------------
function toggleRelay(checked) {
  saveStorage(LIVE_RELAY_KEY, !!checked);
  showToast(checked ? "Public relay allowed for PDFs" : "Public relay turned off");
}

async function runLiveCheck() {
  const out = document.getElementById("live-status");
  out.style.whiteSpace = "pre-line";
  out.style.color = "var(--accent)";
  if (!navigator.onLine) {
    out.textContent = "You are offline. Connect to the internet and try again.";
    return;
  }
  out.textContent = "Checking…";
  const lines = [];
  let sample = null;
  try {
    const r = await liveLatestNotices(6);
    lines.push(`✅ Notices feed works (${r.items.length} notices read)`);
    sample = r.items.flatMap((i) => i.pdfs)[0] || null;
  } catch (e) {
    lines.push("❌ Notices feed: " + liveReason(e));
  }
  if (sample) {
    let direct = true;
    try {
      await liveFetchPdf(sample.url, "direct");
      lines.push("✅ PDFs can be downloaded directly");
    } catch (e) {
      direct = false;
      lines.push("❌ PDFs are blocked by the website (normal for most sites)");
    }
    if (!direct) {
      if (!relayEnabled()) lines.push("ℹ️ Public relay is off. Switch it on below, or upload PDFs yourself.");
      else {
        try {
          await liveFetchPdf(sample.url, "relay");
          lines.push("✅ PDFs work through the public relay");
        } catch (e) {
          lines.push("❌ The public relays did not answer. Upload PDFs yourself.");
        }
      }
    }
  } else if (lines[0].startsWith("✅")) lines.push("ℹ️ No PDF links found to test.");
  out.style.color = lines.some((l) => l.startsWith("❌")) ? "var(--text-muted)" : "var(--success)";
  out.textContent = lines.join("\n");
}
